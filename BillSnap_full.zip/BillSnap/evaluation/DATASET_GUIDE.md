# BillSnap Dataset Collection Guide

## Directory Structure

```
evaluation/
  dataset/
    bills/          ← 15 real bill images
    non_bills/      ← 5 non-bill images
  results/
    results_template.csv   ← fill this in after running evaluation
  scripts/
    evaluate.js            ← CLI evaluation script
```

## Bill Images (15 required)

Collect bills representing the following variety:

| # | Type | Example | Naming |
|---|------|---------|--------|
| 1 | Restaurant receipt | Café / QSR | bill_001.jpg |
| 2 | Grocery supermarket | DMart, Reliance Smart | bill_002.jpg |
| 3 | Grocery supermarket (different) | Big Bazaar, More | bill_003.jpg |
| 4 | Electricity bill | BESCOM, MSEDCL | bill_004.jpg |
| 5 | Mobile/internet bill | Airtel, Jio | bill_005.jpg |
| 6 | Fuel / petrol receipt | HP, IOC pump | bill_006.jpg |
| 7 | Pharmacy receipt | MedPlus, Apollo | bill_007.jpg |
| 8 | Clothing / shopping | Lifestyle, Westside | bill_008.jpg |
| 9 | Crumpled/wrinkled bill | Any type, slightly crumpled | bill_009.jpg |
| 10 | Blurry/out-of-focus | Real bill, slightly blurry | bill_010.jpg |
| 11 | Handwritten bill | Vegetable vendor / local shop | bill_011.jpg |
| 12 | Angled photograph | Real bill at ~30° angle | bill_012.jpg |
| 13 | Small slip receipt | ATM slip or SMS receipt photo | bill_013.jpg |
| 14 | Water / utility bill | Municipal water or gas | bill_014.jpg |
| 15 | Online order invoice | Amazon / Flipkart printed | bill_015.jpg |

## Non-Bill Images (5 required)

| # | Type | Naming |
|---|------|--------|
| 1 | Selfie or portrait photo | non_bill_001.jpg |
| 2 | Aadhaar card or ID card | non_bill_002.jpg |
| 3 | Screenshot (non-receipt) | non_bill_003.jpg |
| 4 | Food photograph | non_bill_004.jpg |
| 5 | Landscape or general photo | non_bill_005.jpg |

## Image Collection Rules

- Use REAL images — do not use synthetic or AI-generated bills.
- Collect with explicit permission or use your own bills.
- Redact any sensitive personal information before submission.
- Supported formats: JPG, PNG, WEBP.
- Minimum resolution: 400 × 300 px.
- Preferred resolution: 1080 × 1920 px (phone camera quality).

## Running Evaluation

```bash
cd evaluation/scripts
npm install tesseract.js

# Evaluate a single image
node evaluate.js --image ../dataset/bills/bill_001.jpg

# Then manually fill results_template.csv
```

## Accuracy Metrics to Calculate

After running all 20 images:

```
Classification Accuracy = Correct classifications / 20

Bill Detection Rate = Correctly identified bills / 15
Non-Bill Rejection Rate = Correctly rejected non-bills / 5

(for bills only):
Merchant Accuracy = Correct merchants / 15
Date Accuracy = Correct dates / 15
Amount Accuracy = Correct amounts / 15
Category Accuracy = Correct categories / 15
```

A field is "correct" if it matches the actual value within reasonable tolerance:
- Merchant: same main business name (case-insensitive, ignoring abbreviations)
- Date: exact day/month/year match
- Amount: within ±1 of actual total
- Category: exact category match
