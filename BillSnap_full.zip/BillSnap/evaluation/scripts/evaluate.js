#!/usr/bin/env node
/**
 * BillSnap Evaluation Script
 *
 * Usage:
 *   node evaluate.js --image <path> [--type bill|non_bill]
 *   node evaluate.js --batch <results-csv-path>
 *
 * This script runs the same classification and extraction pipeline used in the
 * browser through Node.js using Tesseract.js and the same heuristics.
 *
 * Dependencies: tesseract.js, sharp (optional, for image preprocessing)
 *
 * Install: npm install tesseract.js
 */

import { createWorker } from 'tesseract.js'
import { readFileSync, writeFileSync, existsSync } from 'fs'
import { join, basename } from 'path'

// ── Classification heuristics (mirror of src/services/classificationService.ts) ──

const STRONG_BILL_KEYWORDS = [
  'total', 'subtotal', 'sub-total', 'grand total', 'amount due', 'amount paid',
  'invoice', 'receipt', 'bill', 'tax', 'gst', 'vat', 'cgst', 'sgst', 'igst',
  'payment', 'cash', 'paid', 'change', 'balance', 'thank you for shopping',
  'customer copy', 'order no', 'invoice no', 'bill no', 'receipt no'
]

const MEDIUM_BILL_KEYWORDS = [
  'qty', 'quantity', 'item', 'description', 'price', 'rate',
  'discount', 'offer', 'mrp', 'net payable', 'amount', 'rs', '₹', 'inr'
]

const NON_BILL_INDICATORS = [
  'aadhaar', 'aadhar', 'pan card', 'passport', 'voter', 'driving licence'
]

function classifyText(text) {
  const lower = text.toLowerCase()
  let score = 0

  const strongHits = STRONG_BILL_KEYWORDS.filter(k => lower.includes(k)).length
  if (strongHits >= 3) score += 0.40
  else if (strongHits >= 1) score += 0.20

  const medHits = MEDIUM_BILL_KEYWORDS.filter(k => lower.includes(k)).length
  if (medHits >= 4) score += 0.20
  else if (medHits >= 2) score += 0.10

  const amounts = (lower.match(/(?:₹|rs\.?|inr|\$|£|€)\s*[\d,]+(?:\.\d{1,2})?/gi) ?? []).length
  if (amounts >= 2) score += 0.15
  else if (amounts >= 1) score += 0.08

  const dates = (text.match(/\b\d{1,2}[-/\.]\d{1,2}[-/\.]\d{2,4}\b/g) ?? []).length
  if (dates >= 1) score += 0.10

  const itemLines = (text.match(/^.{3,40}\s+[\d,]+(?:\.\d{2})?$/gim) ?? []).length
  if (itemLines >= 3) score += 0.15

  for (const kw of NON_BILL_INDICATORS) {
    if (lower.includes(kw)) { score -= 0.30; break }
  }

  if (text.trim().length < 30) score -= 0.20

  score = Math.min(1, Math.max(0, score))
  return { isBill: score >= 0.30, confidence: score }
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function evaluateImage(imagePath) {
  console.log(`\nEvaluating: ${basename(imagePath)}`)

  const worker = await createWorker('eng', 1, { logger: () => {} })

  try {
    const { data } = await worker.recognize(imagePath)
    const text = data.text
    const ocrConfidence = data.confidence

    const { isBill, confidence } = classifyText(text)

    // Simple amount extraction
    const amounts = [...text.matchAll(/(?:total|grand total|payable)[^\n]*?([\d,]+(?:\.\d{2})?)/gi)]
    const amount = amounts.length > 0
      ? parseFloat(amounts[0][1].replace(/,/g, ''))
      : 0

    // Simple merchant extraction
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 2)
    const merchant = lines.find(l => !/^\d|total|invoice|receipt|tax/i.test(l)) ?? 'Unknown'

    // Date extraction
    const dateMatch = text.match(/\b(\d{1,2}[-/\.]\d{1,2}[-/\.]\d{2,4})\b/)
    const date = dateMatch ? dateMatch[0] : ''

    return {
      file: basename(imagePath),
      predictedType: isBill ? 'bill' : 'non_bill',
      classificationConfidence: confidence.toFixed(2),
      ocrConfidence: ocrConfidence.toFixed(0),
      merchant: merchant.slice(0, 40),
      date,
      amount: amount > 0 ? amount.toFixed(2) : ''
    }
  } finally {
    await worker.terminate()
  }
}

// ── CLI ───────────────────────────────────────────────────────────────────────

const args = process.argv.slice(2)
const imageArg = args[args.indexOf('--image') + 1]

if (imageArg) {
  if (!existsSync(imageArg)) {
    console.error(`File not found: ${imageArg}`)
    process.exit(1)
  }
  evaluateImage(imageArg).then(result => {
    console.table([result])
  }).catch(err => {
    console.error('Error:', err.message)
    process.exit(1)
  })
} else {
  console.log(`
BillSnap Evaluation Script
Usage:
  node evaluate.js --image <path/to/image.jpg>

For batch evaluation, see evaluation/results/results_template.csv
and fill in the Predicted Type column after running each image.
  `)
}
