# BillSnap

**AI-powered bill scanning and expense tracking — Progressive Web App**

BillSnap lets you photograph or upload bills and receipts. It extracts merchant, date, amount, and category automatically using a hybrid OCR + Vision LLM pipeline, lets you review and correct the results, and saves everything locally on your device.

---

## Screenshots

> Add screenshots in `docs/screenshots/` after running the app.

---

## Why PWA Instead of React Native?

| Factor | PWA (chosen) | React Native |
|--------|-------------|-------------|
| Development speed | Hours (one codebase) | Days (platform setup) |
| Camera access | `getUserMedia` API | Native module required |
| App distribution | Shareable URL, no store needed | App Store / Play Store |
| OCR library | Tesseract.js runs in browser | Needs native bridge |
| Local storage | IndexedDB (unlimited) | AsyncStorage / SQLite |
| Offline support | Service Worker + Workbox | Expo OfflineProvider |

PWA was the right choice for a demo/internship project: faster to build, easier to share with reviewers, and equally capable for the required features.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19 + TypeScript + Vite 8 |
| Styling | Tailwind CSS 4 |
| Icons | Lucide React |
| OCR | Tesseract.js 5 |
| Storage | IndexedDB via Dexie.js 4 |
| Charts | Recharts 2 |
| Routing | React Router 7 |
| PWA | vite-plugin-pwa + Workbox |
| Backend | Node.js + Express (optional API proxy) |
| Vision LLM | OpenAI gpt-4o-mini (optional) |

---

## Project Structure

```
BillSnap/
  frontend/           React PWA
  backend/            Express API proxy (optional)
  evaluation/         Dataset, scripts, results
  docs/               Architecture, ML approach, interview prep
  .env.example        Environment variable template
```

---

## Setup

### Prerequisites
- Node.js 18+ 
- npm 9+

### Frontend (required)

```bash
cd frontend
npm install
npm run dev
# → http://localhost:5173
```

The app works immediately in OCR-only mode — no API key needed.

### Backend (optional — for Vision LLM extraction)

```bash
cd backend
npm install

# Create .env from template
cp ../.env.example .env
# Add your OPENAI_API_KEY to .env

npm run dev
# → http://localhost:4000
```

Then create `frontend/.env`:
```
VITE_BACKEND_URL=http://localhost:4000
```

Restart the frontend dev server.

### Build for production

```bash
cd frontend
npm run build
# Output in frontend/dist/
```

---

## Environment Variables

| Variable | Location | Required | Description |
|----------|----------|----------|-------------|
| `OPENAI_API_KEY` | `backend/.env` | No | OpenAI API key for Vision LLM |
| `PORT` | `backend/.env` | No | Backend port (default: 4000) |
| `FRONTEND_URL` | `backend/.env` | No | CORS origin (default: localhost:5173) |
| `VITE_BACKEND_URL` | `frontend/.env` | No | Backend URL (leave blank for OCR-only) |

---

## ML Pipeline

See [`docs/ml_approach.md`](docs/ml_approach.md) for the full pipeline documentation.

**Short version:**
1. Image preprocessing (grayscale + contrast stretch)
2. OCR (Tesseract.js — in-browser, private)
3. Bill/non-bill classification (heuristic keyword scoring)
4. Field extraction: merchant, date, amount, category
5. Vision LLM enrichment (optional, via backend proxy)
6. Confidence assessment per field
7. Human review before saving

---

## Evaluation

See [`evaluation/DATASET_GUIDE.md`](evaluation/DATASET_GUIDE.md) for instructions on collecting test images.

```bash
cd evaluation/scripts
npm install tesseract.js
node evaluate.js --image ../dataset/bills/bill_001.jpg
```

Results go in [`evaluation/results/results_template.csv`](evaluation/results/results_template.csv).

---

## Known Limitations

- Tesseract struggles with heavily handwritten bills
- Very crumpled or angled images may extract poorly
- Vision API requires network — not available offline
- Large images (> 20MB) are rejected to avoid browser memory issues
- Tesseract initialisation takes 2–4 seconds on first scan

---

## Documentation

| Document | Description |
|----------|-------------|
| [`docs/architecture.md`](docs/architecture.md) | System design and component structure |
| [`docs/ml_approach.md`](docs/ml_approach.md) | ML pipeline details and rationale |
| [`docs/product_reflection.md`](docs/product_reflection.md) | What works, limitations, future ideas |
| [`docs/interview_preparation.md`](docs/interview_preparation.md) | 20 interview Q&As + demo script |

---

## Contributing

This is an internship assignment project. Do not push to any public repository without reviewing the contents for sensitive information.

---

## Licence

MIT
