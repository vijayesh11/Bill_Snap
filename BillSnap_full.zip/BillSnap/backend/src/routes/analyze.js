import { Router } from 'express'
import { analyzeImageWithVision } from '../services/visionService.js'

export const analyzeRoute = Router()

analyzeRoute.post('/', async (req, res) => {
  try {
    const { image, ocrText } = req.body

    // Accept either raw OCR text or a base64 image (OCR done client-side)
    const textToAnalyze = ocrText ?? image

    if (!textToAnalyze || typeof textToAnalyze !== 'string') {
      return res.status(400).json({ error: 'image or ocrText field is required' })
    }

    const result = await analyzeImageWithVision(textToAnalyze)
    return res.json(result)
  } catch (err) {
    console.error('[Vision API error]', err.message)

    if (err.message?.includes('JSON')) {
      return res.status(500).json({ error: 'Failed to parse Groq response', fallback: true })
    }
    if (err.status === 429 || err.message?.includes('rate limit')) {
      return res.status(429).json({ error: 'Groq rate limit — try again shortly', fallback: true })
    }
    if (err.status === 401 || err.message?.includes('API key')) {
      return res.status(401).json({ error: 'Invalid Groq API key', fallback: true })
    }

    return res.status(500).json({
      error: err.message ?? 'Groq request failed',
      fallback: true
    })
  }
})
