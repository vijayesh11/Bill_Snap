/**
 * Groq Vision Service (backend)
 * Calls Groq text models with OCR-extracted text to analyse bills.
 * Mirrors the frontend visionApiService.ts logic so both give consistent results.
 */

const GROQ_API_KEY = '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'
const GROQ_URL    = 'https://api.groq.com/openai/v1/chat/completions'

const TEXT_MODELS = [
  'openai/gpt-oss-120b',
  'openai/gpt-oss-20b',
  'qwen/qwen3.8-27b',
  'allam-2-7b',
]

const CATEGORIES = [
  'Food', 'Groceries', 'Shopping', 'Transport', 'Healthcare',
  'Education', 'Utilities', 'Entertainment', 'Travel', 'Fuel', 'Restaurant', 'Other',
]

function detectCurrency(text) {
  const t = text.toLowerCase()
  if (t.includes('rs') || t.includes('inr') || t.includes('rupee')) return 'INR'
  if (t.includes('gbp') || t.includes('pound')) return 'GBP'
  if (t.includes('eur') || t.includes('euro')) return 'EUR'
  if (t.includes('usd') || t.includes('dollar')) return 'USD'
  return 'INR'
}

function buildPrompt(ocrText) {
  const currency = detectCurrency(ocrText)
  return `You are an expert AI agent for handwritten bill detection and expense data extraction.

Extract ONLY these 4 fields from the OCR text of a handwritten or printed bill:
  1. merchant  — business/shop name
  2. date      — transaction date in YYYY-MM-DD format
  3. amount    — final total payable as a plain number (no symbols)
  4. category  — expense category

OCR TEXT:
"""
${ocrText}
"""

DETECTED CURRENCY HINT: ${currency}

=====================================
FIX COMMON OCR ERRORS (handwritten bills)
=====================================
Handwritten "00" in paise column is misread as letters:
  "60 w"/"60 co"/"60 oo"/"60 v"/"60 u" → 60.00
  Rule: any letter/symbol after a number in an amount column = paise ".00"

Indian total notation: "Rs 525/-" or "Rs. 525/-" → 525.00  (the /- means "only")
Number misreads: "l4"/"I4" at line start → 14  |  "O" in numbers → 0
IGNORE: phone numbers, serial numbers like "No. 04747", GST numbers, PIN codes

=====================================
IS THIS A BILL?
=====================================
YES: "CASH MEMO", item list with prices, any shop/hotel/hospital receipt
NO: ID cards, Aadhaar, PAN, selfies, food photos, news articles, menus with no Total

=====================================
EXTRACT THE 4 FIELDS
=====================================
MERCHANT: Business name from bill header. "CASH MEMO" is NOT the merchant.
DATE: YYYY-MM-DD. 2-digit years: 00-29=2000s, 30-99=1900s. Return null if not found.
AMOUNT priority:
  #1 "Rs XXX/-" anywhere → that IS the final total
  #2 Label: "Total"/"Grand Total"/"Net Amount"/"Amount Payable"
  #3 Subtotal minus discount (last/smallest number at bottom)
  #4 Amount in words  |  #5 Last number in right column
  NEVER use phone numbers, serial numbers, GST numbers.
CURRENCY: Rs/INR → INR | $ → USD | £ → GBP | € → EUR | default: ${currency}
CATEGORY — pick one: ${CATEGORIES.join(', ')}
  Restaurant/cafe/dhaba → Restaurant  |  Hotel stay → Travel  |  Petrol pump → Fuel
  Taxi/bus/train → Transport  |  School/books → Education  |  Pharmacy → Healthcare
  Electricity/phone bill → Utilities  |  Supermarket → Groceries

CONFIDENCE: "high"=clearly readable(VERIFIED) | "medium"=inferred(REVIEW) | "low"=unclear(UNCERTAIN)
Return null for value and "low" for confidence if a field cannot be determined.
NEVER hallucinate or fabricate values not visible in the bill.

Respond ONLY with valid JSON — no markdown, no explanation:
{
  "isBill": true,
  "notBillReason": "only if isBill is false",
  "merchant": { "value": "People's Publishing House (P) Ltd.", "confidence": "high" },
  "date":     { "value": "2002-12-05", "confidence": "medium" },
  "amount":   { "value": 525.00, "currency": "INR", "confidence": "high" },
  "category": { "value": "Education", "confidence": "high" }
}`
}

async function callGroq(model, ocrText) {
  const res = await fetch(GROQ_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model,
      messages: [{ role: 'user', content: buildPrompt(ocrText) }],
      max_tokens: 512,
      temperature: 0.1,
    }),
  })

  const body = await res.text()
  if (!res.ok) {
    const err = new Error(`Groq ${res.status}: ${body}`)
    err.status = res.status
    throw err
  }

  const json = JSON.parse(body)
  const content = json.choices?.[0]?.message?.content ?? ''
  if (!content) throw new Error('Empty response from Groq')

  return JSON.parse(
    content.replace(/^```json\s*/i, '').replace(/\s*```$/i, '').trim()
  )
}

async function callGroqWithFallback(ocrText) {
  let lastError = null
  for (const model of TEXT_MODELS) {
    try {
      console.log(`[BillSnap backend] Trying model: ${model}`)
      const result = await callGroq(model, ocrText)
      console.log(`[BillSnap backend] Success: ${model}`)
      return result
    } catch (err) {
      console.warn(`[BillSnap backend] ${model} failed:`, err.message)
      lastError = err
      if (err.status === 401) throw new Error('Invalid Groq API key')
      if (err.status === 429) throw new Error('Groq rate limit — wait a moment')
    }
  }
  throw new Error(`All Groq models failed. Last: ${lastError?.message}`)
}

/**
 * Main export — receives OCR text (extracted by frontend Tesseract),
 * sends to Groq, returns structured bill data.
 */
export async function analyzeImageWithVision(ocrText) {
  const raw = await callGroqWithFallback(ocrText)

  if (!raw.isBill) {
    return {
      isValid: false,
      notBillReason: raw.notBillReason ?? 'Not a bill or receipt',
      merchant: '', date: '', amount: 0, currency: 'INR',
      category: 'Other',
      classificationConfidence: 0.1,
      classificationReason: raw.notBillReason ?? 'Not a bill',
      confidence: { merchant: 'low', date: 'low', amount: 'low', category: 'low' },
      rawText: ocrText,
      extractionMethod: 'vision-api',
    }
  }

  const rawAmount = raw.amount?.value
  const amount = rawAmount && rawAmount > 0 ? parseFloat(String(rawAmount)) : 0
  const currency = raw.amount?.currency ?? detectCurrency(ocrText)
  const category = CATEGORIES.includes(raw.category?.value) ? raw.category.value : 'Other'

  return {
    isValid: true,
    merchant:  raw.merchant?.value  ?? 'Unknown Merchant',
    date:      raw.date?.value      ?? '',
    amount,
    currency,
    category,
    classificationConfidence: 0.95,
    classificationReason: 'Classified by Groq AI',
    confidence: {
      merchant: raw.merchant?.confidence ?? 'low',
      date:     raw.date?.confidence     ?? 'low',
      amount:   raw.amount?.confidence   ?? 'low',
      category: raw.category?.confidence ?? 'low',
    },
    rawText: ocrText,
    extractionMethod: 'vision-api',
  }
}
