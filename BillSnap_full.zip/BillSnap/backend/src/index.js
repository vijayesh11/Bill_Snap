import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import { analyzeRoute } from './routes/analyze.js'

const app = express()
const PORT = process.env.PORT ?? 4000

app.use(cors({
  origin: process.env.FRONTEND_URL ?? 'http://localhost:5173',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type']
}))

app.use(express.json({ limit: '25mb' }))

app.get('/api/health', (_, res) => res.json({ status: 'ok' }))
app.use('/api/analyze', analyzeRoute)

app.use((err, _req, res, _next) => {
  console.error(err)
  res.status(500).json({ error: 'Internal server error' })
})

app.listen(PORT, () => {
  console.log(`BillSnap backend running on port ${PORT}`)
  console.log('[INFO] Groq AI ready — no API key setup needed')
})
