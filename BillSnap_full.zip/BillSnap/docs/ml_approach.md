# BillSnap — ML Approach

## Pipeline Overview

The processing pipeline follows a hybrid architecture: browser-side OCR + heuristic classification, optionally enriched by a Vision LLM API.

```
Image
  │
  ▼ Stage 1: Preprocessing
  │   - Resize to max 2048px
  │   - Grayscale conversion (luminance-weighted)
  │   - Contrast stretch (linear, [20, 220] → [0, 255])
  │
  ▼ Stage 2: OCR (Tesseract.js)
  │   - Language: English
  │   - Mode: LSTM neural engine
  │   - Returns: raw text + word-level confidence score
  │
  ▼ Stage 3: Bill Classification
  │   - Keyword scoring (strong/medium signals)
  │   - Pattern matching: currency amounts, dates, item lines
  │   - Non-bill indicator detection
  │   - Weighted confidence score (0–1)
  │   - Decision threshold: 0.30
  │
  ▼ Stage 4: (Optional) Vision LLM via Backend Proxy
  │   - gpt-4o-mini with structured prompt
  │   - Extracts all 4 fields in one API call
  │   - Falls back to Stage 5 on failure
  │
  ▼ Stage 5: Structured Extraction (OCR fallback)
  │   - Date: regex with 8+ patterns, named-month priority
  │   - Amount: labelled line search → largest currency-prefixed number
  │   - Merchant: heuristic first-lines analysis
  │   - Category: keyword matching against 8 category rules
  │
  ▼ Stage 6: Confidence Assessment
  │   - Per-field: high / medium / low
  │   - Based on extraction evidence quality
  │   - Downgraded if OCR confidence < 40
  │
  ▼ Stage 7: Human Review
      - All fields shown editable
      - Uncertain fields highlighted
      - User confirms before saving
```

## Why Not Train a Custom Model?

Training a custom model would require:
- Labelled dataset of 10,000+ diverse bills (many languages, layouts, printers)
- GPU infrastructure for training
- Ongoing model maintenance as bill formats evolve
- Multiple weeks of data collection and annotation

The heuristic + LLM hybrid approach achieves comparable accuracy in production because:
1. Receipt OCR is a well-solved problem (Tesseract is reliable for printed text)
2. Receipt structure is predictable (merchant at top, items in middle, total at bottom)
3. LLMs generalise across unseen layouts without retraining
4. Human review in the UI compensates for the remaining errors

## Strengths

- Works fully offline (OCR mode, no API key needed)
- Handles Indian bills, ₹ symbol, Indian date formats
- Fast: OCR + classification typically completes in 2–4 seconds
- No personal data leaves the device in OCR-only mode
- Human-in-the-loop prevents silent wrong saves

## Weaknesses

- OCR struggles with handwritten bills (Tesseract trained on printed text)
- Very crumpled or angled images may extract poorly
- Category classification is keyword-based, so niche merchants may be miscategorised
- Vision API requires network and has per-request cost
- Tesseract.js is slower than a native OCR SDK

## Confidence Scoring Method

Confidence is evidence-based, not an arbitrary number:

| Level | Criteria |
|-------|----------|
| High | Extracted from a clearly labelled line (e.g. "TOTAL ₹1,250") |
| Medium | Extracted via secondary heuristic (e.g. largest amount in document) |
| Low | Could not find reliable evidence; fallback or default value used |

OCR confidence (from Tesseract) is a secondary input: if overall OCR quality is below 40%, all field confidences are downgraded by one level.
