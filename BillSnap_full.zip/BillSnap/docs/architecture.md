# BillSnap — Architecture

## Overview

BillSnap is a Progressive Web Application (PWA) that allows users to scan and manage bills and receipts. It operates primarily client-side, with an optional backend for Vision LLM enrichment.

```
┌─────────────────────────────────────────┐
│          Browser (React + Vite)         │
│                                         │
│  ┌─────────────┐   ┌─────────────────┐  │
│  │  UI Layer   │   │  ML Pipeline    │  │
│  │  (React)    │   │  (Tesseract.js) │  │
│  └─────┬───────┘   └────────┬────────┘  │
│        │                    │           │
│  ┌─────▼────────────────────▼────────┐  │
│  │         IndexedDB (Dexie.js)      │  │
│  └───────────────────────────────────┘  │
└───────────────────┬─────────────────────┘
                    │ (optional)
          ┌─────────▼──────────┐
          │  Express Backend   │
          │  (API key proxy)   │
          └─────────┬──────────┘
                    │
          ┌─────────▼──────────┐
          │  OpenAI Vision API │
          │  (gpt-4o-mini)     │
          └────────────────────┘
```

## Component Structure

```
frontend/src/
  components/
    ui/           # Reusable design system components
    bills/        # Bill-specific components (BillCard, ReviewForm)
    camera/       # ImageCapture, ProcessingStatus
  pages/          # Route-level page components
  layouts/        # AppLayout with navigation
  services/       # ML pipeline, OCR, Vision API
  hooks/          # useBills, useStats (Dexie live queries)
  database/       # Dexie schema and repository pattern
  utils/          # Image processing, formatting
  types/          # Shared TypeScript interfaces
```

## Data Flow

1. User captures/uploads image
2. `processingPipeline.ts` orchestrates the full pipeline
3. OCR extracts raw text
4. Classification service scores the text
5. If valid: extraction service parses fields
6. Vision API enriches fields (if configured)
7. User reviews and edits in ReviewForm
8. Bill is saved to IndexedDB via billRepository
9. Dexie live queries update all views automatically

## Storage Schema

```typescript
bills {
  id: auto-increment primary key
  merchant: string
  date: string (ISO YYYY-MM-DD)
  amount: number
  currency: string
  category: Category enum
  imageDataUrl: string | null
  confidence: FieldConfidence
  rawText: string
  createdAt: timestamp
  updatedAt: timestamp
}
```

## PWA Configuration

- Vite PWA plugin generates service worker and manifest
- Workbox strategies: CacheFirst for static assets
- Offline: app shell works fully offline; OCR may work offline (Tesseract files cached after first use); Vision API requires network
