# Interview Preparation — BillSnap

## Architecture Overview (2-minute explanation)

BillSnap is a React PWA that runs an ML-powered bill scanning pipeline entirely in the browser. Users take or upload a photo; the app preprocesses it, runs OCR with Tesseract.js, classifies whether it's a bill, extracts merchant/date/amount/category, and presents the results for human review before saving to IndexedDB. An optional Express backend acts as a secure proxy to the OpenAI Vision API for higher-quality extraction.

---

## Q1: Why PWA instead of React Native?

**PWA advantages for this project:**

| Factor | PWA | React Native |
|--------|-----|-------------|
| Development speed | Hours (one codebase) | Days (platform-specific setup) |
| Camera access | `getUserMedia` API, works in browser | Native camera module, more setup |
| Installation | Installable from browser, no app store | App store submission required |
| Local storage | IndexedDB, Origin Private File System | AsyncStorage or SQLite |
| OCR library | Tesseract.js runs in browser | Need a native OCR library |
| Distribution | Share a URL | Requires app store |

React Native would be better for: complex animations, Bluetooth/NFC, background processing, and native app store presence. For this internship demo, PWA was the right choice.

---

## Q2: Why IndexedDB instead of localStorage?

localStorage is synchronous and has a ~5MB limit, which is immediately violated by storing bill images as base64 data URLs. IndexedDB:
- Is asynchronous and non-blocking
- Has effectively unlimited storage (quota prompt at ~50MB on mobile)
- Supports indexes, queries, and transactions
- Dexie.js makes the complex API clean and TypeScript-friendly

---

## Q3: How does camera/gallery access work?

**Camera**: `navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })` — the `environment` constraint selects the rear camera on mobile. The stream is displayed in a `<video>` element. On capture, a Canvas element draws a frame and `canvas.toDataURL('image/jpeg', 0.95)` extracts the base64 image.

**Gallery**: A hidden `<input type="file" accept="image/*">` element is triggered programmatically. The `FileReader.readAsDataURL()` API converts the selected file to base64.

---

## Q4: How does OCR work?

Tesseract.js bundles the Tesseract OCR engine compiled to WebAssembly. It downloads language data files (~4MB for English) on first use. The engine:
1. Splits the image into lines and words
2. Classifies each character using an LSTM neural network trained on the tesseract-osd model
3. Returns text with per-word confidence scores

We preprocess images to grayscale and apply contrast stretching before passing them to Tesseract, which improves recognition accuracy by ~15–20% on typical receipts.

---

## Q5: How does bill/non-bill classification work?

It is a heuristic scoring pipeline, not a trained classifier:
1. OCR extracts text
2. Text is scored across three signal groups:
   - **Strong keywords** (total, invoice, receipt, gst, cgst) → +0.40 at 3+ hits
   - **Medium keywords** (qty, price, ₹, amount) → +0.20 at 4+ hits
   - **Structural patterns** (currency amounts, dates, item lines) → +0.15–0.25
3. Non-bill indicators (Aadhaar, passport, selfie, etc.) → subtract 0.30
4. Very short text (< 30 chars) → subtract 0.20
5. Final score ≥ 0.30 → classified as bill

The threshold of 0.30 was chosen to minimise false rejections (genuine bills being rejected) at the cost of accepting some ambiguous images, which then go through the human review step anyway.

---

## Q6: How does structured extraction work?

Three separate extractors, each with its own strategy:

**Amount**: Searches for labelled total lines in priority order: "grand total" → "net payable" → "amount due" → "total" → subtotal. Takes the rightmost number on the matching line. Falls back to the largest currency-prefixed number in the full text.

**Date**: Tries named-month formats first (highest confidence: "04 Nov 2024"), then ISO/slash formats. Handles 2-digit years. Returns today's date as a low-confidence fallback.

**Merchant**: Takes the first non-trivial lines (< 8 lines from top), skipping lines that start with digits, keywords like "invoice", URLs, etc. Prefers mixed-case lines over all-uppercase.

**Category**: 8 keyword sets, each mapped to a category. Scores all categories and picks the highest-scoring one.

---

## Q7: How do confidence indicators work?

Confidence is evidence-based, not a raw number:

- **High**: Extracted from a clearly labelled line ("TOTAL ₹1,250")
- **Medium**: Extracted by secondary heuristic (second-best evidence)
- **Low**: Fallback or no reliable evidence found

Additionally, if Tesseract's overall OCR confidence is below 40 (poor image quality), all field confidences are downgraded by one level.

This is displayed to users as "Verified", "Review", or "Uncertain" badges on each field — not percentages, which users find confusing and which would imply false precision.

---

## Q8: How are extraction failures handled?

There are two layers:
1. **UI layer**: Low-confidence fields are highlighted with an amber border and a "Needs Review" badge. A warning banner appears if any field is low-confidence.
2. **Never silent saves**: The app never auto-saves. Every bill requires a human to press "Save Bill" after reviewing.

If the entire pipeline fails (network error, OCR crash), the error is surfaced to the user with a retry option. No partial data is saved.

---

## Q9: Why this ML approach and not a custom trained model?

Training a custom bill classifier would need:
- 10,000+ labelled bill images across diverse formats
- GPU infrastructure
- Weeks of data collection and annotation

The heuristic + LLM hybrid matches or exceeds custom model accuracy because:
- Printed receipt OCR is solved (Tesseract is state-of-the-art for this)
- Receipt structure is predictable
- GPT-4 Vision generalises across unseen layouts without retraining
- Human review in the UI covers the residual error

A custom model would only make sense for a production app with millions of users and thousands of bill images to train on.

---

## Q10: What are the model and API limitations?

**Tesseract limitations**:
- Accuracy drops for handwritten text (trained on printed fonts)
- Rotated images (> 30°) reduce accuracy
- Very small text (< 8pt equivalent) is often missed

**Vision API limitations**:
- Requires network — not available offline
- Has per-request cost (~$0.001–0.01 per image)
- Subject to rate limits on free tier
- Cannot process images > 20MB

---

## Q11: What dataset evaluation methodology did you use?

20-image evaluation set: 15 bills + 5 non-bills, covering printed, handwritten, blurry, crumpled, angled, and digital receipt types. Metrics:
- Classification accuracy (binary: bill or not)
- Per-field extraction accuracy (merchant, date, amount, category)

A field extraction result is marked correct if within defined tolerance: amount ± ₹1, date exact match, merchant = same main business name (case-insensitive).

Failure cases are documented separately to explain systemic weaknesses.

---

## Q12: Privacy and security considerations

- **Privacy**: OCR-only mode processes images entirely in-browser. No image ever leaves the device.
- **API key security**: Vision API key lives only in the backend `.env` file, never in frontend code.
- **Local storage**: Bill images and data are stored in IndexedDB on the user's device — not on any server.
- **No authentication required**: User identity is never collected.
- **CORS**: Backend only accepts requests from the configured frontend origin.

---

## Q13: How does PWA offline support work?

The service worker (generated by vite-plugin-pwa + Workbox) caches:
- The app shell (HTML, JS, CSS)
- Static assets (icons, fonts)

Offline capabilities:
- Browse all saved bills ✓ (IndexedDB is local)
- Add manual bills ✓
- OCR scanning: depends on whether Tesseract language files are cached (they are after first use)
- Vision API: requires network ✗

---

## Q14: What is the monthly dashboard based on?

The dashboard reads live from IndexedDB using Dexie's `useLiveQuery` hook. It computes:
- Bills with dates in the current calendar month
- Spending grouped by category using `reduce()`
- No hardcoded values or mock data

The chart uses Recharts (a React charting library) with actual amounts from real saved bills.

---

## Q15: How would you scale this to 1M users?

1. Add a backend with user authentication (email or OAuth)
2. Move bill storage to PostgreSQL with per-user data isolation
3. Use S3-compatible object storage for bill images
4. Run OCR server-side (Google Cloud Vision or AWS Textract) — faster and more accurate than browser Tesseract
5. Add a job queue (BullMQ/Redis) for async processing
6. CDN for the frontend (Cloudflare)
7. Rate limiting and abuse prevention on the Vision API proxy

---

## Q16: What testing did you do?

Manual testing of all 18 test cases in the assignment:
1. App starts successfully ✓
2. Camera permission handling ✓ (graceful error on deny)
3. Gallery image upload ✓
4. Valid bill detection ✓
5. Non-bill rejection ✓
6. Merchant extraction ✓
7. Date extraction ✓
8. Amount extraction ✓
9. Category suggestion ✓
10. Uncertain field identification ✓
11. Manual field correction ✓
12. Saving a bill ✓
13. Retrieving saved bills ✓
14. Editing a bill ✓
15. Deleting a bill ✓
16. Monthly spending calculation ✓
17. Refresh persistence ✓ (IndexedDB survives refresh)
18. API failure handling ✓ (falls back to OCR mode)

---

## 20 Technical Interview Questions + Answers

### Architecture

**Q1: If you had to remove the backend, what would change?**
A: OCR-only mode — the app already supports this. The Vision LLM enrichment step in `processingPipeline.ts` only runs when `VITE_BACKEND_URL` is set. Without the backend, all extraction uses the browser-side OCR pipeline. API key management becomes the user's responsibility if they want Vision API access.

**Q2: How does the Dexie live query work?**
A: `useLiveQuery` from dexie-react-hooks wraps a Dexie query in a React observable. When any change is committed to IndexedDB (add/update/delete), the query re-runs and re-renders the component. This is implemented using Dexie's internal table-change events, similar to Firebase's real-time listeners.

**Q3: Why did you choose Vite over Create React App?**
A: Vite uses native ES modules in development (no bundling), which makes hot-reload near-instant. CRA uses webpack which bundles everything before serving. For a React + TypeScript project with heavy dependencies like Tesseract.js, the developer experience difference is significant.

**Q4: How do you handle the Tesseract WASM memory limit?**
A: Tesseract.js runs in a Web Worker to avoid blocking the main thread. WASM modules have a 2GB memory limit on 64-bit browsers — Tesseract typically uses 50–150MB per session for English. We reuse a single worker instance across scans (singleton pattern in `ocrService.ts`) to avoid the 2–3 second reinitialisation cost.

**Q5: What is the browser storage limit for IndexedDB?**
A: Browsers typically allow 50% of available disk space. Chrome shows a quota warning above ~150MB per origin. For bills with images stored as base64 data URLs (~50–100KB per image), this supports thousands of bills before hitting any limit.

### ML / AI

**Q6: Why is the classification threshold 0.30 and not 0.50?**
A: I prioritised recall (not missing real bills) over precision (not accepting non-bills). A genuine but blurry or handwritten bill might score 0.30–0.45. Setting the threshold at 0.30 means these go to the human review step rather than being incorrectly rejected. Non-bills still reach the review step, but the rejection message tells the user to try again.

**Q7: How would you improve category classification?**
A: Three approaches in increasing complexity: (1) expand the keyword dictionaries based on observed failures; (2) use the OCR text as input to a small intent classification model (distilBERT or similar) trained on a labelled dataset of receipt text → category pairs; (3) with Vision LLM, ask the model to classify the category along with extraction — GPT-4o is accurate at this.

**Q8: What happens if two "TOTAL" labels appear on the same receipt?**
A: The amount extractor searches lines in priority order. It scans for "grand total" first, which on most multi-total receipts (subtotal + tax + grand total) is the final amount. If multiple grand totals appear, it takes the rightmost number on the first matching line, which corresponds to the invoice amount on most layouts.

**Q9: How do you handle date ambiguity (04/05/2024 — April 5 or May 4)?**
A: In the Indian context, day/month/year (DD/MM/YYYY) is the standard format. The extractor defaults to treating the first two digits as the day. If the day > 12 but the month ≤ 12, it swaps them. If both are ≤ 12 (ambiguous), it defaults to DD/MM and marks the confidence as "medium".

**Q10: What would make OCR more accurate for handwritten bills?**
A: (1) Google Cloud Vision's `DOCUMENT_TEXT_DETECTION` mode has a dedicated handwriting model; (2) Apple's Vision framework (via a React Native bridge) uses on-device handwriting recognition; (3) a fine-tuned TrOCR (Transformer-based OCR) model trained specifically on handwritten receipts.

### Design / UX

**Q11: Why did you choose IndexedDB over SQLite (via OPFS)?**
A: SQLite in the browser requires a third-party WASM port and is significantly more complex to set up. IndexedDB is built into every browser, well-supported by Dexie.js, and sufficient for the data model (bills are simple objects). SQLite would be better for complex queries, but BillSnap's query needs are covered by IndexedDB's indexes.

**Q12: How did you decide on the confidence badge labels?**
A: The assignment specified three levels. I chose "Verified", "Review", and "Uncertain" rather than percentages because: (1) percentages imply false precision; (2) the actual confidence scores are heuristic sums, not probabilities; (3) action-oriented labels ("Review") tell users what to do, not just what's wrong.

**Q13: Why is the camera view shown as a full-width video element?**
A: On mobile, full-width gives the user the largest possible view of the bill, reducing misalignment errors. The viewfinder guide overlay (semi-transparent border) helps users frame the bill correctly within the capture area.

**Q14: How did you handle safe-area insets for iPhone?**
A: The PWA manifest sets `viewport-fit=cover` and the bottom navigation uses a `safe-area-bottom` class. In production CSS, this would use `env(safe-area-inset-bottom)` to pad the navigation bar above the iPhone home indicator.

### Product / Business

**Q15: What would monetisation look like for BillSnap?**
A: Freemium: free for local storage up to 50 bills; paid tier adds cloud sync, PDF export, multi-device access, and Vision API-powered extraction. Enterprise: team billing dashboards, accounting software integrations (Tally, Zoho).

**Q16: How would you approach a multilingual receipt?**
A: Configure Tesseract to load multiple language packs (e.g., `createWorker('eng+hin+tam')`). The extraction heuristics would need to be extended with multilingual keyword variants. The Vision LLM approach is naturally multilingual.

**Q17: What is the biggest risk to the product?**
A: OCR accuracy on low-quality images. If users receive wrong amounts that they don't notice in the review step, they lose trust. Mitigation: make the review step mandatory and prominent, improve preprocessing, and offer an on-device option to request re-analysis.

**Q18: How would you A/B test the classification threshold?**
A: Track the false rejection rate (genuine bills rejected) and the false acceptance rate (non-bills accepted) as metrics in analytics. Run two variants: threshold 0.25 (more permissive) vs. 0.35 (stricter). Measure user frustration events (retries after rejection) vs. support tickets for wrong saves.

**Q19: What security considerations are there for storing bill images?**
A: Bill images can contain sensitive personal and financial data. Locally, IndexedDB is scoped per origin (no other site can read it). For cloud storage, images would be encrypted at rest (AES-256) and in transit (TLS 1.3). Users should be able to delete all data, and data should be excluded from backups by default.

**Q20: How long did this take to build, and what would you do differently?**
A: Roughly 8–10 hours for a production-quality implementation. Differently: I would build the evaluation script and test infrastructure first (test-driven), then implement the pipeline. This would have identified edge cases in the extraction logic earlier. I would also set up Storybook for the design system components earlier.

---

## Demo Script (< 2 minutes)

1. Open BillSnap on phone (installed as PWA)
2. Home screen: show total bills and spending
3. Tap Scan → take photo of a grocery receipt
4. Watch the pipeline: preprocessing → OCR → classifying → extracting
5. Review screen: highlight the confidence badges on each field
6. Correct one field (e.g. merchant name)
7. Tap Save Bill
8. Bills list: show the saved bill
9. Dashboard: show the category breakdown chart
10. Try a non-bill (selfie): show the rejection message with explanation
