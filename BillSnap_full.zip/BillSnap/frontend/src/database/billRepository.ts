import { db } from './db'
import type { Bill, Category } from '@/types'

export const billRepository = {
  async add(bill: Omit<Bill, 'id'>): Promise<number> {
    return db.bills.add(bill) as Promise<number>
  },

  async getAll(): Promise<Bill[]> {
    return db.bills.orderBy('date').reverse().toArray()
  },

  async getById(id: number): Promise<Bill | undefined> {
    return db.bills.get(id)
  },

  async update(id: number, changes: Partial<Omit<Bill, 'id'>>): Promise<void> {
    await db.bills.update(id, { ...changes, updatedAt: Date.now() })
  },

  async delete(id: number): Promise<void> {
    await db.bills.delete(id)
  },

  async search(query: string): Promise<Bill[]> {
    const q = query.toLowerCase()
    return db.bills
      .filter(b =>
        b.merchant.toLowerCase().includes(q) ||
        b.category.toLowerCase().includes(q)
      )
      .reverse()
      .sortBy('date')
  },

  async filterByCategory(category: Category): Promise<Bill[]> {
    return db.bills
      .where('category')
      .equals(category)
      .reverse()
      .sortBy('date')
  },

  async getThisMonth(): Promise<Bill[]> {
    const now = new Date()
    const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10)
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().slice(0, 10)
    return db.bills
      .where('date')
      .between(start, end, true, true)
      .reverse()
      .sortBy('date')
  },

  async getStats(): Promise<{
    totalBills: number
    totalSpending: number
    thisMonthSpending: number
    thisMonthBills: number
    spendingByCategory: Record<string, number>
    recentBills: Bill[]
  }> {
    const all = await db.bills.toArray()
    const now = new Date()
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10)
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().slice(0, 10)

    const thisMonth = all.filter(b => b.date >= startOfMonth && b.date <= endOfMonth)

    const spendingByCategory: Record<string, number> = {}
    for (const bill of thisMonth) {
      spendingByCategory[bill.category] = (spendingByCategory[bill.category] ?? 0) + bill.amount
    }

    const recent = [...all]
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 5)

    return {
      totalBills: all.length,
      totalSpending: all.reduce((s, b) => s + b.amount, 0),
      thisMonthSpending: thisMonth.reduce((s, b) => s + b.amount, 0),
      thisMonthBills: thisMonth.length,
      spendingByCategory,
      recentBills: recent
    }
  }
}
