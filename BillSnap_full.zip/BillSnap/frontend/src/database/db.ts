import Dexie, { type EntityTable } from 'dexie'
import type { Bill } from '@/types'

class BillSnapDB extends Dexie {
  bills!: EntityTable<Bill, 'id'>

  constructor() {
    super('BillSnapDB')
    this.version(1).stores({
      bills: '++id, merchant, date, amount, currency, category, createdAt, updatedAt'
    })
  }
}

export const db = new BillSnapDB()
