import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { Home, Receipt, BarChart2, ScanLine } from 'lucide-react'

interface AppLayoutProps {
  children: React.ReactNode
}

const navItems = [
  { to: '/', icon: Home, label: 'Home' },
  { to: '/bills', icon: Receipt, label: 'Bills' },
  { to: '/scan', icon: ScanLine, label: 'Scan', primary: true },
  { to: '/dashboard', icon: BarChart2, label: 'Analytics' },
]

export function AppLayout({ children }: AppLayoutProps) {
  const location = useLocation()

  const isActive = (to: string) =>
    to === '/' ? location.pathname === '/' : location.pathname.startsWith(to)

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100dvh',
        background: 'var(--color-bg)',
      }}
    >
      {/* ── Top header ─────────────────────────────────────────────────── */}
      <header
        className="glass"
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 40,
          borderBottom: '1px solid var(--color-border)',
          height: 'var(--header-h)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 1.25rem',
        }}
      >
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: '9px',
              background: 'var(--color-navy)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 2px 8px rgba(27,46,68,0.32)',
            }}
          >
            <ScanLine size={17} color="white" strokeWidth={2} />
          </div>
          <span
            style={{
              fontSize: '17px',
              fontWeight: 800,
              letterSpacing: '-0.03em',
              color: 'var(--color-text-primary)',
            }}
          >
            Bill<span style={{ color: 'var(--color-accent)' }}>Snap</span>
          </span>
        </div>

        {/* Month label */}
        <span
          style={{
            fontSize: '11px',
            fontWeight: 500,
            color: 'var(--color-text-tertiary)',
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
          }}
        >
          {new Date().toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}
        </span>
      </header>

      {/* ── Page content ───────────────────────────────────────────────── */}
      <main style={{ flex: 1, paddingBottom: 'var(--nav-h)' }}>
        {children}
      </main>

      {/* ── Bottom navigation ──────────────────────────────────────────── */}
      <nav
        className="glass"
        style={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          zIndex: 40,
          borderTop: '1px solid var(--color-border)',
          height: 'var(--nav-h)',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-around',
            maxWidth: '30rem',
            margin: '0 auto',
            height: '100%',
            padding: '0 0.5rem',
          }}
        >
          {navItems.map(({ to, icon: Icon, label, primary }) => {
            const active = isActive(to)

            if (primary) {
              return (
                <NavLink
                  key={to}
                  to={to}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '5px',
                    textDecoration: 'none',
                    marginTop: '-20px',
                  }}
                >
                  <div
                    style={{
                      width: 52,
                      height: 52,
                      borderRadius: '50%',
                      background: active
                        ? 'var(--color-navy-hover)'
                        : 'var(--color-navy)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: 'var(--shadow-navy)',
                      transition: 'background 0.15s ease, transform 0.15s ease',
                    }}
                  >
                    <Icon size={22} color="white" strokeWidth={2} />
                  </div>
                  <span
                    style={{
                      fontSize: '10px',
                      fontWeight: 600,
                      color: 'var(--color-text-tertiary)',
                      letterSpacing: '0.03em',
                      lineHeight: 1,
                    }}
                  >
                    {label}
                  </span>
                </NavLink>
              )
            }

            return (
              <NavLink
                key={to}
                to={to}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '5px',
                  padding: '8px 14px',
                  borderRadius: 'var(--radius-lg)',
                  textDecoration: 'none',
                  color: active ? 'var(--color-navy)' : 'var(--color-text-tertiary)',
                  transition: 'color 0.15s ease',
                  minWidth: 56,
                  position: 'relative',
                }}
              >
                <Icon size={20} strokeWidth={active ? 2.5 : 1.75} />
                <span
                  style={{
                    fontSize: '10px',
                    fontWeight: active ? 700 : 500,
                    letterSpacing: '0.02em',
                    lineHeight: 1,
                  }}
                >
                  {label}
                </span>
                {active && (
                  <div
                    style={{
                      position: 'absolute',
                      bottom: 2,
                      left: '50%',
                      transform: 'translateX(-50%)',
                      width: 4,
                      height: 4,
                      borderRadius: '50%',
                      background: 'var(--color-navy)',
                    }}
                  />
                )}
              </NavLink>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
