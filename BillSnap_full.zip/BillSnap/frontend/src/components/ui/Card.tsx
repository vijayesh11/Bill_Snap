import React from 'react'

interface CardProps {
  children: React.ReactNode
  className?: string
  onClick?: () => void
  hoverable?: boolean
  padding?: 'sm' | 'md' | 'lg' | 'none'
}

const paddingStyles = {
  none: '',
  sm: 'p-3',
  md: 'p-4',
  lg: 'p-6'
}

export function Card({ children, className = '', onClick, hoverable = false, padding = 'md' }: CardProps) {
  const interactive = hoverable || onClick
  return (
    <div
      className={`
        bg-[var(--color-surface)]
        border border-[var(--color-border)]
        rounded-[var(--radius-lg)]
        shadow-[var(--shadow-sm)]
        ${paddingStyles[padding]}
        ${interactive ? 'cursor-pointer transition-shadow duration-150 hover:shadow-[var(--shadow-md)] hover:border-[var(--color-border-strong)]' : ''}
        ${className}
      `}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => { if (e.key === 'Enter') onClick() } : undefined}
    >
      {children}
    </div>
  )
}

export function CardDivider() {
  return <hr className="border-t border-[var(--color-border)] my-4" />
}
