import React from 'react'
import type { ConfidenceLevel } from '@/types'

interface BadgeProps {
  children: React.ReactNode
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'neutral'
  size?: 'sm' | 'md'
}

const variantStyles: Record<string, string> = {
  default: 'bg-[var(--color-surface-alt)] text-[var(--color-text-secondary)] border border-[var(--color-border)]',
  success: 'bg-[var(--color-accent-light)] text-[var(--color-accent-hover)] border border-green-200',
  warning: 'bg-[var(--color-warning-light)] text-[var(--color-warning)] border border-amber-200',
  danger: 'bg-[var(--color-danger-light)] text-[var(--color-danger)] border border-red-200',
  neutral: 'bg-gray-100 text-gray-600 border border-gray-200'
}

const sizeStyles: Record<string, string> = {
  sm: 'px-1.5 py-0.5 text-[10px] font-semibold tracking-wide uppercase',
  md: 'px-2 py-1 text-xs font-medium'
}

export function Badge({ children, variant = 'default', size = 'md' }: BadgeProps) {
  return (
    <span className={`inline-flex items-center rounded-sm ${variantStyles[variant]} ${sizeStyles[size]}`}>
      {children}
    </span>
  )
}

export function ConfidenceBadge({ level }: { level: ConfidenceLevel }) {
  const map: Record<ConfidenceLevel, { label: string; variant: 'success' | 'warning' | 'danger' }> = {
    high: { label: 'VERIFIED', variant: 'success' },
    medium: { label: 'REVIEW', variant: 'warning' },
    low: { label: 'UNCERTAIN', variant: 'danger' }
  }
  const { label, variant } = map[level]
  return <Badge variant={variant} size="sm">{label}</Badge>
}
