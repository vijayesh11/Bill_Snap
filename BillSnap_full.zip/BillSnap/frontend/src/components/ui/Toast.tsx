import React, { createContext, useContext, useCallback, useState } from 'react'
import { CheckCircle, XCircle, Info, X } from 'lucide-react'

type ToastType = 'success' | 'error' | 'info'

interface Toast {
  id: string
  type: ToastType
  message: string
}

interface ToastContextValue {
  showToast: (message: string, type?: ToastType) => void
}

const ToastContext = createContext<ToastContextValue>({ showToast: () => {} })

export function useToast() {
  return useContext(ToastContext)
}

const icons: Record<ToastType, React.ReactNode> = {
  success: <CheckCircle size={16} className="text-[var(--color-accent)]" />,
  error: <XCircle size={16} className="text-[var(--color-danger)]" />,
  info: <Info size={16} className="text-blue-600" />
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  const showToast = useCallback((message: string, type: ToastType = 'info') => {
    const id = crypto.randomUUID()
    setToasts(prev => [...prev, { id, type, message }])
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id))
    }, 3500)
  }, [])

  const dismiss = (id: string) => setToasts(prev => prev.filter(t => t.id !== id))

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed bottom-20 left-0 right-0 flex flex-col items-center gap-2 z-50 px-4 pointer-events-none">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className="
              flex items-center gap-2.5 px-4 py-3
              bg-[var(--color-surface)] border border-[var(--color-border)]
              rounded-[var(--radius-lg)] shadow-[var(--shadow-lg)]
              max-w-sm w-full text-sm pointer-events-auto
              fade-in
            "
          >
            {icons[toast.type]}
            <span className="flex-1 text-[var(--color-text-primary)]">{toast.message}</span>
            <button
              onClick={() => dismiss(toast.id)}
              className="text-[var(--color-text-tertiary)] hover:text-[var(--color-text-primary)] transition-colors"
              aria-label="Dismiss"
            >
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}
