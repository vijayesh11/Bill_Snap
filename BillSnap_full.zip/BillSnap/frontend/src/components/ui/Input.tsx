import React from 'react'

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  hint?: string
  leftIcon?: React.ReactNode
}

export function Input({ label, error, hint, leftIcon, className = '', id, ...props }: InputProps) {
  const inputId = id ?? label?.toLowerCase().replace(/\s+/g, '-')

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label
          htmlFor={inputId}
          className="text-sm font-medium text-[var(--color-text-primary)]"
        >
          {label}
        </label>
      )}
      <div className="relative">
        {leftIcon && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-tertiary)]">
            {leftIcon}
          </span>
        )}
        <input
          id={inputId}
          className={`
            w-full px-3 py-2 text-sm
            bg-[var(--color-surface)] text-[var(--color-text-primary)]
            border rounded-[var(--radius-md)]
            placeholder:text-[var(--color-text-tertiary)]
            transition-colors duration-150
            ${leftIcon ? 'pl-9' : ''}
            ${error
              ? 'border-[var(--color-danger)] focus:outline-[var(--color-danger)]'
              : 'border-[var(--color-border)] focus:border-[var(--color-accent)] focus:outline-[var(--color-accent)]'
            }
            ${className}
          `}
          {...props}
        />
      </div>
      {error && <p className="text-xs text-[var(--color-danger)]">{error}</p>}
      {hint && !error && <p className="text-xs text-[var(--color-text-tertiary)]">{hint}</p>}
    </div>
  )
}
