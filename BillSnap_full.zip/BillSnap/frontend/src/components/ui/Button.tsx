import React from 'react'

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline'
type Size = 'sm' | 'md' | 'lg'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  loading?: boolean
  fullWidth?: boolean
  leftIcon?: React.ReactNode
  rightIcon?: React.ReactNode
}

const base = `
  inline-flex items-center justify-center gap-2
  font-medium rounded-[var(--radius-md)]
  transition-all duration-150 cursor-pointer
  disabled:opacity-50 disabled:cursor-not-allowed
  focus-visible:outline-2 focus-visible:outline-offset-2
`

const variants: Record<Variant, string> = {
  primary: `
    bg-[var(--color-navy)] text-white
    hover:bg-[var(--color-navy-hover)]
    active:scale-[0.98]
    shadow-sm
  `,
  secondary: `
    bg-[var(--color-accent)] text-white
    hover:bg-[var(--color-accent-hover)]
    active:scale-[0.98]
    shadow-sm
  `,
  ghost: `
    bg-transparent text-[var(--color-text-primary)]
    hover:bg-[var(--color-surface-alt)]
    active:scale-[0.98]
  `,
  danger: `
    bg-[var(--color-danger)] text-white
    hover:bg-red-800
    active:scale-[0.98]
    shadow-sm
  `,
  outline: `
    bg-transparent text-[var(--color-text-primary)]
    border border-[var(--color-border-strong)]
    hover:border-[var(--color-text-secondary)]
    hover:bg-[var(--color-surface-alt)]
    active:scale-[0.98]
  `
}

const sizes: Record<Size, string> = {
  sm: 'px-3 py-1.5 text-sm',
  md: 'px-4 py-2 text-sm',
  lg: 'px-5 py-3 text-base'
}

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  fullWidth = false,
  leftIcon,
  rightIcon,
  children,
  disabled,
  className = '',
  ...props
}: ButtonProps) {
  return (
    <button
      className={`${base} ${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
      ) : leftIcon}
      {children}
      {!loading && rightIcon}
    </button>
  )
}
