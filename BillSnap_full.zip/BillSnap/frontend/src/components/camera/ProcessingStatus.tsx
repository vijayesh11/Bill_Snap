import React from 'react'
import { ScanLine, Eye, Tags, CheckCircle, AlertCircle } from 'lucide-react'
import type { ProcessingState } from '@/types'

interface ProcessingStatusProps {
  state: ProcessingState
}

const stageConfig = {
  idle: { icon: null, label: '' },
  preprocessing: {
    icon: <Eye size={16} />,
    label: 'Preparing image for analysis…'
  },
  ocr: {
    icon: <ScanLine size={16} />,
    label: 'Reading text from image…'
  },
  classifying: {
    icon: <Eye size={16} />,
    label: 'Verifying this is a bill…'
  },
  extracting: {
    icon: <Tags size={16} />,
    label: 'Extracting bill details…'
  },
  done: {
    icon: <CheckCircle size={16} />,
    label: 'Processing complete'
  },
  error: {
    icon: <AlertCircle size={16} />,
    label: 'An error occurred'
  }
}

export function ProcessingStatus({ state }: ProcessingStatusProps) {
  if (state.stage === 'idle') return null

  const config = stageConfig[state.stage]
  const isError = state.stage === 'error'
  const isDone = state.stage === 'done'

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2.5">
        <span className={`flex-shrink-0 ${isError ? 'text-[var(--color-danger)]' : isDone ? 'text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]'}`}>
          {config.icon}
        </span>
        <span className={`text-sm ${isError ? 'text-[var(--color-danger)]' : 'text-[var(--color-text-secondary)]'}`}>
          {isError ? state.error : config.label}
        </span>
        {!isDone && !isError && (
          <span className="ml-auto flex-shrink-0">
            <span className="inline-block w-4 h-4 border-2 border-[var(--color-accent)] border-t-transparent rounded-full animate-spin" />
          </span>
        )}
      </div>

      {/* Progress bar */}
      {!isError && (
        <div className="h-1 bg-[var(--color-surface-alt)] rounded-full overflow-hidden">
          <div
            className="h-full bg-[var(--color-accent)] rounded-full transition-all duration-500 ease-out"
            style={{ width: `${state.progress}%` }}
          />
        </div>
      )}
    </div>
  )
}
