import React, { useRef, useState, useCallback } from 'react'
import { Camera, Upload, X, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { fileToDataUrl, isSupportedImageFormat } from '@/utils/imageProcessing'

interface ImageCaptureProps {
  onImageSelected: (dataUrl: string) => void
  onCancel?: () => void
}

type Mode = 'select' | 'camera' | 'preview'

export function ImageCapture({ onImageSelected, onCancel }: ImageCaptureProps) {
  const [mode, setMode] = useState<Mode>('select')
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [cameraActive, setCameraActive] = useState(false)

  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop())
      streamRef.current = null
    }
    setCameraActive(false)
  }, [])

  const startCamera = useCallback(async () => {
    setError(null)
    setMode('camera')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } }
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
        setCameraActive(true)
      }
    } catch (err) {
      const e = err as Error
      if (e.name === 'NotAllowedError') {
        setError('Camera permission denied. Please allow camera access in your browser settings.')
      } else if (e.name === 'NotFoundError') {
        setError('No camera found on this device. Please upload an image instead.')
      } else {
        setError('Unable to access camera. Please use the upload option instead.')
      }
      setMode('select')
    }
  }, [])

  const capturePhoto = useCallback(() => {
    if (!videoRef.current || !cameraActive) return
    const video = videoRef.current
    const canvas = document.createElement('canvas')
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    canvas.getContext('2d')!.drawImage(video, 0, 0)
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95)
    stopCamera()
    setPreviewUrl(dataUrl)
    setMode('preview')
  }, [cameraActive, stopCamera])

  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!isSupportedImageFormat(file)) {
      setError('Unsupported format. Please upload a JPG, PNG, or WEBP image.')
      return
    }
    if (file.size > 20 * 1024 * 1024) {
      setError('File is too large. Please upload an image under 20MB.')
      return
    }
    setError(null)
    const dataUrl = await fileToDataUrl(file)
    setPreviewUrl(dataUrl)
    setMode('preview')
    // reset input so the same file can be re-selected
    e.target.value = ''
  }, [])

  const handleConfirm = useCallback(() => {
    if (!previewUrl) return
    onImageSelected(previewUrl)
  }, [previewUrl, onImageSelected])

  const handleRetake = useCallback(() => {
    setPreviewUrl(null)
    setMode('select')
    setError(null)
  }, [])

  const handleCancel = useCallback(() => {
    stopCamera()
    setPreviewUrl(null)
    setMode('select')
    setError(null)
    onCancel?.()
  }, [stopCamera, onCancel])

  // ── Camera view ─────────────────────────────────────────────────────────────
  if (mode === 'camera') {
    return (
      <div className="flex flex-col items-center gap-4">
        <div className="relative w-full aspect-[4/3] bg-black rounded-[var(--radius-lg)] overflow-hidden">
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            playsInline
            muted
            autoPlay
          />
          {!cameraActive && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
            </div>
          )}
          {/* Viewfinder guide */}
          <div className="absolute inset-6 border-2 border-white/40 rounded pointer-events-none" />
        </div>

        <div className="flex gap-3 w-full">
          <Button variant="ghost" onClick={handleCancel} fullWidth>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={capturePhoto}
            disabled={!cameraActive}
            fullWidth
            leftIcon={<Camera size={16} />}
          >
            Capture
          </Button>
        </div>
      </div>
    )
  }

  // ── Preview view ─────────────────────────────────────────────────────────────
  if (mode === 'preview' && previewUrl) {
    return (
      <div className="flex flex-col gap-4">
        <div className="relative">
          <img
            src={previewUrl}
            alt="Preview"
            className="w-full max-h-72 object-contain rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface-alt)]"
          />
          <button
            onClick={handleRetake}
            className="absolute top-2 right-2 w-8 h-8 bg-black/60 rounded-full flex items-center justify-center text-white hover:bg-black/80 transition-colors"
            aria-label="Remove image"
          >
            <X size={16} />
          </button>
        </div>

        <div className="flex gap-3">
          <Button variant="outline" onClick={handleRetake} leftIcon={<RotateCcw size={15} />}>
            Replace
          </Button>
          <Button variant="secondary" onClick={handleConfirm} fullWidth>
            Analyse Bill
          </Button>
        </div>
      </div>
    )
  }

  // ── Selection view ─────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col gap-4">
      {error && (
        <div className="p-3 rounded-[var(--radius-md)] bg-[var(--color-danger-light)] border border-red-200 text-sm text-[var(--color-danger)]">
          {error}
        </div>
      )}

      {/* Upload area */}
      <label
        className="
          flex flex-col items-center justify-center gap-3
          border-2 border-dashed border-[var(--color-border-strong)]
          rounded-[var(--radius-lg)] p-8 cursor-pointer
          hover:border-[var(--color-accent)] hover:bg-[var(--color-accent-light)]/30
          transition-all duration-150 group
        "
      >
        <div className="w-12 h-12 rounded-xl bg-[var(--color-surface-alt)] border border-[var(--color-border)] flex items-center justify-center group-hover:border-[var(--color-accent)] transition-colors">
          <Upload size={22} className="text-[var(--color-text-secondary)] group-hover:text-[var(--color-accent)] transition-colors" />
        </div>
        <div className="text-center">
          <p className="text-sm font-medium text-[var(--color-text-primary)]">Upload from gallery</p>
          <p className="text-xs text-[var(--color-text-tertiary)] mt-0.5">JPG, PNG or WEBP · Max 20MB</p>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/jpg,image/png,image/webp"
          onChange={handleFileUpload}
          className="sr-only"
        />
      </label>

      <div className="flex items-center gap-3">
        <div className="flex-1 h-px bg-[var(--color-border)]" />
        <span className="text-xs text-[var(--color-text-tertiary)]">or</span>
        <div className="flex-1 h-px bg-[var(--color-border)]" />
      </div>

      <Button
        variant="primary"
        size="lg"
        onClick={startCamera}
        fullWidth
        leftIcon={<Camera size={18} />}
      >
        Take a Photo
      </Button>

      {onCancel && (
        <Button variant="ghost" onClick={handleCancel} fullWidth>
          Cancel
        </Button>
      )}
    </div>
  )
}
