import React from 'react'
import { ChevronRight, UtensilsCrossed, ShoppingCart, Zap, Car, Heart, ShoppingBag, Music2, BookOpen, Receipt } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import type { Bill } from '@/types'
import { formatCurrency, formatDateShort, truncate } from '@/utils/formatting'

interface CategoryConfig {
  icon: LucideIcon
  iconBg: string
  iconColor: string
  badgeBg: string
  badgeColor: string
}

const CATEGORY_CONFIG: Record<string, CategoryConfig> = {
  'Food & Dining': {
    icon: UtensilsCrossed,
    iconBg: '#FFF4ED',
    iconColor: '#C2410C',
    badgeBg: '#FFF4ED',
    badgeColor: '#9A3412',
  },
  'Groceries': {
    icon: ShoppingCart,
    iconBg: '#F0FDF4',
    iconColor: '#15803D',
    badgeBg: '#F0FDF4',
    badgeColor: '#14532D',
  },
  'Utilities': {
    icon: Zap,
    iconBg: '#EFF6FF',
    iconColor: '#1D4ED8',
    badgeBg: '#EFF6FF',
    badgeColor: '#1E40AF',
  },
  'Transportation': {
    icon: Car,
    iconBg: '#F0F9FF',
    iconColor: '#0369A1',
    badgeBg: '#F0F9FF',
    badgeColor: '#075985',
  },
  'Healthcare': {
    icon: Heart,
    iconBg: '#FFF1F2',
    iconColor: '#BE123C',
    badgeBg: '#FFF1F2',
    badgeColor: '#9F1239',
  },
  'Shopping': {
    icon: ShoppingBag,
    iconBg: '#FAF5FF',
    iconColor: '#7E22CE',
    badgeBg: '#FAF5FF',
    badgeColor: '#6B21A8',
  },
  'Entertainment': {
    icon: Music2,
    iconBg: '#FDF2F8',
    iconColor: '#9D174D',
    badgeBg: '#FDF2F8',
    badgeColor: '#831843',
  },
  'Education': {
    icon: BookOpen,
    iconBg: '#EEF2FF',
    iconColor: '#3730A3',
    badgeBg: '#EEF2FF',
    badgeColor: '#312E81',
  },
  'Other': {
    icon: Receipt,
    iconBg: '#F9FAFB',
    iconColor: '#6B7280',
    badgeBg: '#F9FAFB',
    badgeColor: '#374151',
  },
}

const DEFAULT_CONFIG: CategoryConfig = CATEGORY_CONFIG['Other']

interface BillCardProps {
  bill: Bill
  onClick?: () => void
  compact?: boolean
}

export function BillCard({ bill, onClick, compact = false }: BillCardProps) {
  const config = CATEGORY_CONFIG[bill.category] ?? DEFAULT_CONFIG
  const Icon = config.icon

  return (
    <div
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={onClick ? (e) => e.key === 'Enter' && onClick() : undefined}
      className="bill-card"
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        padding: compact ? '10px 14px' : '14px 16px',
        background: 'var(--color-surface)',
        border: '1px solid var(--color-border)',
        borderRadius: 'var(--radius-lg)',
        cursor: onClick ? 'pointer' : 'default',
        boxShadow: 'var(--shadow-xs)',
        userSelect: 'none',
        WebkitTapHighlightColor: 'transparent',
      }}
    >
      {/* Category icon */}
      <div
        style={{
          width: compact ? 38 : 44,
          height: compact ? 38 : 44,
          borderRadius: 'var(--radius-md)',
          background: config.iconBg,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        <Icon size={compact ? 17 : 20} color={config.iconColor} strokeWidth={1.75} />
      </div>

      {/* Info */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <p
          style={{
            fontSize: compact ? '14px' : '15px',
            fontWeight: 600,
            color: 'var(--color-text-primary)',
            letterSpacing: '-0.01em',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            margin: 0,
            lineHeight: 1.3,
          }}
        >
          {truncate(bill.merchant, 28)}
        </p>

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            marginTop: '3px',
          }}
        >
          <span
            style={{
              fontSize: '12px',
              color: 'var(--color-text-tertiary)',
              fontWeight: 400,
            }}
          >
            {formatDateShort(bill.date)}
          </span>
          <span
            style={{
              fontSize: '10px',
              fontWeight: 600,
              padding: '1px 7px',
              borderRadius: 'var(--radius-pill)',
              background: config.badgeBg,
              color: config.badgeColor,
              letterSpacing: '0.01em',
              border: `1px solid ${config.iconBg}`,
            }}
          >
            {bill.category}
          </span>
        </div>
      </div>

      {/* Amount + chevron */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
          flexShrink: 0,
        }}
      >
        <span
          className="amount"
          style={{
            fontSize: compact ? '14px' : '16px',
            fontWeight: 700,
            color: 'var(--color-text-primary)',
            letterSpacing: '-0.02em',
          }}
        >
          {formatCurrency(bill.amount, bill.currency)}
        </span>
        {onClick && (
          <ChevronRight size={15} color="var(--color-text-tertiary)" />
        )}
      </div>
    </div>
  )
}
