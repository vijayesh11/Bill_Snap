import React, { useState } from 'react'
import { CheckCircle, AlertCircle, Sparkles, Eye } from 'lucide-react'
import type { ExtractedBillData, Category } from '@/types'
import { CATEGORIES } from '@/types'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Button } from '@/components/ui/Button'
import { ConfidenceBadge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'

interface ReviewFormProps {
  extracted: ExtractedBillData
  imageDataUrl: string | null
  onSave: (data: {
    merchant: string
    date: string
    amount: number
    currency: string
    category: Category
  }) => Promise<void>
  onDiscard: () => void
  saving?: boolean
}

export function ReviewForm({
  extracted,
  imageDataUrl,
  onSave,
  onDiscard,
  saving = false
}: ReviewFormProps) {
  const [merchant, setMerchant] = useState(extracted.merchant)
  const [date, setDate] = useState(extracted.date)
  const [amount, setAmount] = useState(String(extracted.amount || ''))
  const [currency] = useState(extracted.currency)
  const [category, setCategory] = useState<Category>(extracted.category)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validate = () => {
    const newErrors: Record<string, string> = {}
    if (!merchant.trim()) newErrors.merchant = 'Merchant name is required'
    if (!date) newErrors.date = 'Date is required'
    const amt = parseFloat(amount)
    if (isNaN(amt) || amt < 0) newErrors.amount = 'Please enter a valid amount'
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSave = async () => {
    if (!validate()) return
    await onSave({
      merchant: merchant.trim(),
      date,
      amount: parseFloat(amount),
      currency,
      category
    })
  }

  const hasLowConfidence = Object.values(extracted.confidence).some(c => c === 'low')
  const usedVisionAI = extracted.extractionMethod === 'vision-api'

  return (
    <div className="flex flex-col gap-4 fade-in">
      {/* Classification result */}
      <div className="flex items-start gap-2 p-3 rounded-[var(--radius-md)] bg-[var(--color-accent-light)] border border-green-200">
        <CheckCircle size={16} className="text-[var(--color-accent)] mt-0.5 flex-shrink-0" />
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <p className="text-sm font-medium text-[var(--color-accent-hover)]">Bill detected</p>
            {/* Extraction method badge */}
            <span
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '3px',
                fontSize: '10px',
                fontWeight: 600,
                letterSpacing: '0.03em',
                padding: '2px 6px',
                borderRadius: '999px',
                background: usedVisionAI
                  ? 'rgba(37,99,235,0.10)'
                  : 'rgba(107,114,128,0.12)',
                color: usedVisionAI ? '#1D4ED8' : '#6B7280',
                border: `1px solid ${usedVisionAI ? 'rgba(37,99,235,0.20)' : 'rgba(107,114,128,0.20)'}`,
              }}
            >
              {usedVisionAI
                ? <><Sparkles size={9} />Vision AI</>
                : <><Eye size={9} />OCR</>
              }
            </span>
          </div>
          <p className="text-xs text-green-700 mt-0.5">{extracted.classificationReason}</p>
        </div>
      </div>

      {/* Low confidence warning */}
      {hasLowConfidence && (
        <div className="flex items-start gap-2 p-3 rounded-[var(--radius-md)] bg-[var(--color-warning-light)] border border-amber-200">
          <AlertCircle size={16} className="text-[var(--color-warning)] mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-[var(--color-warning)]">Review needed</p>
            <p className="text-xs text-amber-700 mt-0.5">
              Some fields have low confidence. Please verify the highlighted fields before saving.
            </p>
          </div>
        </div>
      )}

      {/* Bill image thumbnail */}
      {imageDataUrl && (
        <div className="relative">
          <img
            src={imageDataUrl}
            alt="Bill"
            className="w-full max-h-40 object-contain rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-alt)]"
          />
        </div>
      )}

      <Card padding="md">
        <div className="flex flex-col gap-4">
          {/* Merchant */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between mb-0.5">
              <label className="text-sm font-medium text-[var(--color-text-primary)]">Merchant</label>
              <ConfidenceBadge level={extracted.confidence.merchant} />
            </div>
            <Input
              value={merchant}
              onChange={e => setMerchant(e.target.value)}
              error={errors.merchant}
              placeholder="Enter merchant name"
              className={extracted.confidence.merchant === 'low' ? 'border-amber-300' : ''}
            />
          </div>

          {/* Date */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between mb-0.5">
              <label className="text-sm font-medium text-[var(--color-text-primary)]">Date</label>
              <ConfidenceBadge level={extracted.confidence.date} />
            </div>
            <Input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              error={errors.date}
              className={extracted.confidence.date === 'low' ? 'border-amber-300' : ''}
            />
          </div>

          {/* Amount */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between mb-0.5">
              <label className="text-sm font-medium text-[var(--color-text-primary)]">
                Amount ({currency})
              </label>
              <ConfidenceBadge level={extracted.confidence.amount} />
            </div>
            <Input
              type="number"
              min="0"
              step="0.01"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              error={errors.amount}
              placeholder="0.00"
              className={extracted.confidence.amount === 'low' ? 'border-amber-300' : ''}
            />
          </div>

          {/* Category */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between mb-0.5">
              <label className="text-sm font-medium text-[var(--color-text-primary)]">Category</label>
              <ConfidenceBadge level={extracted.confidence.category} />
            </div>
            <Select
              value={category}
              onChange={e => setCategory(e.target.value as Category)}
              options={CATEGORIES.map(c => ({ value: c, label: c }))}
              className={extracted.confidence.category === 'low' ? 'border-amber-300' : ''}
            />
          </div>
        </div>
      </Card>

      {/* Actions */}
      <div className="flex gap-3">
        <Button variant="outline" onClick={onDiscard} disabled={saving}>
          Discard
        </Button>
        <Button
          variant="secondary"
          onClick={handleSave}
          loading={saving}
          fullWidth
        >
          Save Bill
        </Button>
      </div>
    </div>
  )
}
