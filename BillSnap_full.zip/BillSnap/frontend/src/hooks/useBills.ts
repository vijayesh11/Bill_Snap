import { useState, useCallback } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { billRepository } from '@/database/billRepository'
import type { Bill, Category } from '@/types'

export function useBills() {
  const [searchQuery, setSearchQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState<Category | ''>('')
  const [sortOrder, setSortOrder] = useState<'date' | 'amount'>('date')

  const bills = useLiveQuery(async () => {
    if (categoryFilter) return billRepository.filterByCategory(categoryFilter as Category)
    if (searchQuery.trim()) return billRepository.search(searchQuery)
    return billRepository.getAll()
  }, [searchQuery, categoryFilter])

  const sortedBills = bills?.slice().sort((a, b) => {
    if (sortOrder === 'amount') return b.amount - a.amount
    return b.date.localeCompare(a.date)
  })

  const addBill = useCallback(async (bill: Omit<Bill, 'id'>) => {
    return billRepository.add(bill)
  }, [])

  const updateBill = useCallback(async (id: number, changes: Partial<Bill>) => {
    await billRepository.update(id, changes)
  }, [])

  const deleteBill = useCallback(async (id: number) => {
    await billRepository.delete(id)
  }, [])

  return {
    bills: sortedBills ?? [],
    loading: bills === undefined,
    searchQuery,
    setSearchQuery,
    categoryFilter,
    setCategoryFilter,
    sortOrder,
    setSortOrder,
    addBill,
    updateBill,
    deleteBill
  }
}

export function useStats() {
  const stats = useLiveQuery(() => billRepository.getStats())
  return { stats, loading: stats === undefined }
}
