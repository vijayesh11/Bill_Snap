/**
 * Image preprocessing for OCR — optimised for handwritten & printed bills.
 *
 * Pipeline:
 *   1. Upscale small images (min 1500 px on longest side)
 *   2. Grayscale
 *   3. Adaptive local-mean thresholding (Sauvola-style) → handles uneven
 *      lighting, yellowed paper, shadows — far better than global stretch
 *   4. Sharpening (unsharp-mask 5-tap kernel)
 *   5. Return both colour and binarised data-URLs for OCR
 */

export interface PreprocessedImage {
  dataUrl: string
  width: number
  height: number
  grayscaleDataUrl: string   // binarised — fed to Tesseract
}

export async function preprocessImage(source: File | string): Promise<PreprocessedImage> {
  const img = await loadImage(source)

  /* ── 1. Resize ─────────────────────────────────────────────────────────── */
  const MIN_DIM = 1500   // bump from 1200 → better for small handwritten bills
  const MAX_DIM = 2800
  let { width, height } = img

  if (width < MIN_DIM || height < MIN_DIM) {
    const scale = Math.max(MIN_DIM / width, MIN_DIM / height)
    width  = Math.round(width  * scale)
    height = Math.round(height * scale)
  }
  if (width > MAX_DIM || height > MAX_DIM) {
    const scale = Math.min(MAX_DIM / width, MAX_DIM / height)
    width  = Math.round(width  * scale)
    height = Math.round(height * scale)
  }

  /* colour canvas (for thumbnail preview) */
  const colorCanvas = document.createElement('canvas')
  colorCanvas.width = width; colorCanvas.height = height
  colorCanvas.getContext('2d')!.drawImage(img, 0, 0, width, height)
  const dataUrl = colorCanvas.toDataURL('image/jpeg', 0.95)

  /* ── 2. Grayscale ──────────────────────────────────────────────────────── */
  const grayCanvas = document.createElement('canvas')
  grayCanvas.width = width; grayCanvas.height = height
  const gCtx = grayCanvas.getContext('2d')!
  gCtx.drawImage(img, 0, 0, width, height)

  const imgData = gCtx.getImageData(0, 0, width, height)
  const src = imgData.data
  const n   = width * height

  const gray = new Uint8ClampedArray(n)
  for (let i = 0; i < n; i++) {
    const p = i * 4
    gray[i] = Math.round(0.299 * src[p] + 0.587 * src[p + 1] + 0.114 * src[p + 2])
  }

  /* ── 3. Adaptive local-mean threshold (Sauvola-style) ──────────────────
   *  For each pixel compare its value to the mean of a surrounding window.
   *  Ink pixels (dark) are below (mean × k); background pixels are white.
   *  This handles: uneven lighting, shadow on paper, yellowed/aged paper.
   * ──────────────────────────────────────────────────────────────────────── */
  const WINDOW = 25   // neighbourhood radius in px (odd value)
  const K      = 0.85 // fraction of local mean — lower → more ink detected

  // Build integral image (summed area table) for O(1) window sums
  const integral = new Float64Array((width + 1) * (height + 1))
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x
      const ii = (y + 1) * (width + 1) + (x + 1)
      integral[ii] =
        gray[i]
        + integral[ii - 1]
        + integral[ii - (width + 1)]
        - integral[ii - (width + 1) - 1]
    }
  }

  const binarised = new Uint8ClampedArray(n)
  const half = Math.floor(WINDOW / 2)

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const x1 = Math.max(0,       x - half)
      const y1 = Math.max(0,       y - half)
      const x2 = Math.min(width  - 1, x + half)
      const y2 = Math.min(height - 1, y + half)
      const area = (x2 - x1 + 1) * (y2 - y1 + 1)

      // integral image lookup
      const br = (y2 + 1) * (width + 1) + (x2 + 1)
      const tl = y1       * (width + 1) + x1
      const tr = y1       * (width + 1) + (x2 + 1)
      const bl = (y2 + 1) * (width + 1) + x1
      const mean = (integral[br] - integral[tr] - integral[bl] + integral[tl]) / area

      binarised[y * width + x] = gray[y * width + x] < mean * K ? 0 : 255
    }
  }

  /* ── 4. Sharpen the binarised image ────────────────────────────────────── */
  const sharpened = new Uint8ClampedArray(n)
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * width + x
      if (x === 0 || x === width - 1 || y === 0 || y === height - 1) {
        sharpened[idx] = binarised[idx]
        continue
      }
      const val =
        5 * binarised[idx]
        - binarised[idx - 1]
        - binarised[idx + 1]
        - binarised[idx - width]
        - binarised[idx + width]
      sharpened[idx] = Math.min(255, Math.max(0, val))
    }
  }

  /* ── 5. Write back as grayscale RGBA ───────────────────────────────────── */
  for (let i = 0; i < n; i++) {
    const p = i * 4
    src[p] = src[p + 1] = src[p + 2] = sharpened[i]
    src[p + 3] = 255
  }
  gCtx.putImageData(imgData, 0, 0)
  const grayscaleDataUrl = grayCanvas.toDataURL('image/png')  // PNG = lossless for OCR

  return { dataUrl, width, height, grayscaleDataUrl }
}

export function loadImage(source: File | string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload  = () => resolve(img)
    img.onerror = reject
    if (typeof source === 'string') {
      img.src = source
    } else {
      const reader = new FileReader()
      reader.onload  = e => { img.src = e.target!.result as string }
      reader.onerror = reject
      reader.readAsDataURL(source)
    }
  })
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload  = e => resolve(e.target!.result as string)
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

export function isSupportedImageFormat(file: File): boolean {
  return ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'].includes(file.type)
}

export function computeSharpnessScore(dataUrl: string): Promise<number> {
  return new Promise(resolve => {
    const img = new Image()
    img.onload = () => {
      const SIZE = 100
      const canvas = document.createElement('canvas')
      canvas.width = SIZE; canvas.height = SIZE
      const ctx = canvas.getContext('2d')!
      ctx.drawImage(img, 0, 0, SIZE, SIZE)
      const { data } = ctx.getImageData(0, 0, SIZE, SIZE)
      let variance = 0, prev = 0
      for (let i = 0; i < data.length; i += 4) {
        const g = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]
        const diff = g - prev
        variance += diff * diff
        prev = g
      }
      resolve(Math.min(1, variance / (SIZE * SIZE * 1000)))
    }
    img.src = dataUrl
  })
}
