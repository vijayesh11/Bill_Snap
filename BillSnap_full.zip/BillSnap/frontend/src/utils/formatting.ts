import { format, parseISO, isValid } from 'date-fns'

export function formatCurrency(amount: number, currency = '₹'): string {
  if (currency === '₹' || currency === 'INR') {
    return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  }
  return `${currency}${amount.toFixed(2)}`
}

export function formatDate(dateStr: string): string {
  try {
    const d = parseISO(dateStr)
    if (!isValid(d)) return dateStr
    return format(d, 'd MMMM yyyy')
  } catch {
    return dateStr
  }
}

export function formatDateShort(dateStr: string): string {
  try {
    const d = parseISO(dateStr)
    if (!isValid(d)) return dateStr
    return format(d, 'd MMM yyyy')
  } catch {
    return dateStr
  }
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10)
}

export function truncate(str: string, maxLen = 30): string {
  if (str.length <= maxLen) return str
  return str.slice(0, maxLen - 1) + '…'
}
