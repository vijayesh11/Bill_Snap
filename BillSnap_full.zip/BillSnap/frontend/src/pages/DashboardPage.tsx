import React from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { TrendingUp, Receipt, Calendar } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { useStats } from '@/hooks/useBills'
import { formatCurrency } from '@/utils/formatting'

const CATEGORY_COLORS: Record<string, string> = {
  'Food & Dining':   '#EA580C',
  'Groceries':       '#16A34A',
  'Utilities':       '#2563EB',
  'Transportation':  '#0891B2',
  'Healthcare':      '#E11D48',
  'Shopping':        '#9333EA',
  'Entertainment':   '#DB2777',
  'Education':       '#4F46E5',
  'Other':           '#6B7280',
}

export function DashboardPage() {
  const { stats, loading } = useStats()

  const chartData = stats
    ? Object.entries(stats.spendingByCategory)
        .filter(([, v]) => v > 0)
        .sort(([, a], [, b]) => b - a)
        .map(([name, value]) => ({ name, value }))
    : []

  const totalForBreakdown = chartData.reduce((s, d) => s + d.value, 0)

  const now = new Date()
  const monthName = now.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })

  return (
    <div
      className="fade-in"
      style={{
        maxWidth: '32rem',
        margin: '0 auto',
        padding: '1.25rem 1rem 1.5rem',
        display: 'flex',
        flexDirection: 'column',
        gap: '1.25rem',
      }}
    >
      {/* Header */}
      <div>
        <h1
          style={{
            fontSize: '24px',
            fontWeight: 800,
            letterSpacing: '-0.03em',
            color: 'var(--color-text-primary)',
            margin: '0 0 3px',
          }}
        >
          Analytics
        </h1>
        <p
          style={{
            fontSize: '12px',
            color: 'var(--color-text-tertiary)',
            margin: 0,
            fontWeight: 500,
          }}
        >
          {monthName}
        </p>
      </div>

      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {[0, 1, 2].map(i => (
            <div key={i} className="shimmer" style={{ height: '90px' }} />
          ))}
        </div>
      ) : stats?.totalBills === 0 ? (
        <EmptyState
          icon={<TrendingUp size={20} />}
          title="No spending data yet"
          description="Scan your first bill to see your spending dashboard."
        />
      ) : (
        <>
          {/* KPI cards */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            {/* This month */}
            <div
              style={{
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: '16px',
                boxShadow: 'var(--shadow-xs)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '10px' }}>
                <TrendingUp size={13} color="var(--color-text-tertiary)" strokeWidth={2} />
                <span style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  This Month
                </span>
              </div>
              <p
                className="amount"
                style={{ fontSize: '22px', fontWeight: 800, letterSpacing: '-0.03em', color: 'var(--color-text-primary)', margin: '0 0 3px' }}
              >
                {formatCurrency(stats!.thisMonthSpending)}
              </p>
              <p style={{ fontSize: '11px', color: 'var(--color-text-tertiary)', margin: 0 }}>
                {stats!.thisMonthBills} {stats!.thisMonthBills === 1 ? 'bill' : 'bills'}
              </p>
            </div>

            {/* All time */}
            <div
              style={{
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: '16px',
                boxShadow: 'var(--shadow-xs)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '10px' }}>
                <Receipt size={13} color="var(--color-text-tertiary)" strokeWidth={2} />
                <span style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  All Time
                </span>
              </div>
              <p
                className="amount"
                style={{ fontSize: '22px', fontWeight: 800, letterSpacing: '-0.03em', color: 'var(--color-text-primary)', margin: '0 0 3px' }}
              >
                {formatCurrency(stats!.totalSpending)}
              </p>
              <p style={{ fontSize: '11px', color: 'var(--color-text-tertiary)', margin: 0 }}>
                {stats!.totalBills} bills total
              </p>
            </div>
          </div>

          {/* Spending chart */}
          {chartData.length > 0 && (
            <div
              style={{
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: '18px 16px',
                boxShadow: 'var(--shadow-xs)',
              }}
            >
              <h2
                style={{
                  fontSize: '14px',
                  fontWeight: 700,
                  color: 'var(--color-text-primary)',
                  letterSpacing: '-0.01em',
                  margin: '0 0 16px',
                }}
              >
                Spending by Category
              </h2>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 10, fill: 'var(--color-text-tertiary)', fontFamily: 'inherit' }}
                    tickLine={false}
                    axisLine={false}
                    interval={0}
                    angle={-28}
                    textAnchor="end"
                    height={48}
                  />
                  <YAxis
                    tick={{ fontSize: 10, fill: 'var(--color-text-tertiary)', fontFamily: 'inherit' }}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={v => `₹${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`}
                  />
                  <Tooltip
                    formatter={(value: number) => [formatCurrency(value), 'Spent']}
                    contentStyle={{
                      border: '1px solid var(--color-border)',
                      borderRadius: 'var(--radius-md)',
                      boxShadow: 'var(--shadow-md)',
                      fontSize: '12px',
                      fontFamily: 'inherit',
                      background: 'var(--color-surface)',
                    }}
                    cursor={{ fill: 'var(--color-surface-alt)', radius: 4 }}
                  />
                  <Bar dataKey="value" radius={[5, 5, 0, 0]}>
                    {chartData.map((entry) => (
                      <Cell
                        key={entry.name}
                        fill={CATEGORY_COLORS[entry.name] ?? '#6B7280'}
                        fillOpacity={0.9}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Category breakdown list */}
          {chartData.length > 0 && (
            <div
              style={{
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: '18px 16px',
                boxShadow: 'var(--shadow-xs)',
              }}
            >
              <h2
                style={{
                  fontSize: '14px',
                  fontWeight: 700,
                  color: 'var(--color-text-primary)',
                  letterSpacing: '-0.01em',
                  margin: '0 0 14px',
                }}
              >
                Breakdown
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {chartData.map(({ name, value }) => {
                  const pct = totalForBreakdown > 0
                    ? Math.round((value / totalForBreakdown) * 100)
                    : 0
                  const color = CATEGORY_COLORS[name] ?? '#6B7280'
                  return (
                    <div key={name} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      {/* Dot */}
                      <div
                        style={{
                          width: 10,
                          height: 10,
                          borderRadius: '50%',
                          background: color,
                          flexShrink: 0,
                        }}
                      />
                      {/* Category name */}
                      <span
                        style={{
                          fontSize: '13px',
                          color: 'var(--color-text-secondary)',
                          flex: 1,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {name}
                      </span>
                      {/* Progress bar */}
                      <div
                        style={{
                          width: 64,
                          height: 4,
                          borderRadius: 999,
                          background: 'var(--color-surface-alt)',
                          overflow: 'hidden',
                        }}
                      >
                        <div
                          style={{
                            height: '100%',
                            width: `${pct}%`,
                            borderRadius: 999,
                            background: color,
                            transition: 'width 0.5s ease',
                          }}
                        />
                      </div>
                      {/* Pct */}
                      <span
                        style={{
                          fontSize: '11px',
                          color: 'var(--color-text-tertiary)',
                          width: 28,
                          textAlign: 'right',
                          fontWeight: 500,
                        }}
                      >
                        {pct}%
                      </span>
                      {/* Amount */}
                      <span
                        className="amount"
                        style={{
                          fontSize: '13px',
                          fontWeight: 700,
                          color: 'var(--color-text-primary)',
                          width: 72,
                          textAlign: 'right',
                          letterSpacing: '-0.01em',
                        }}
                      >
                        {formatCurrency(value)}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
