import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, Filter, SortDesc, Receipt, ScanLine } from 'lucide-react'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { BillCard } from '@/components/bills/BillCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { Modal } from '@/components/ui/Modal'
import { useBills } from '@/hooks/useBills'
import { CATEGORIES, type Category } from '@/types'

export function BillsPage() {
  const navigate = useNavigate()
  const {
    bills, loading,
    searchQuery, setSearchQuery,
    categoryFilter, setCategoryFilter,
    sortOrder, setSortOrder
  } = useBills()

  const [filterOpen, setFilterOpen] = useState(false)

  return (
    <div className="max-w-lg mx-auto px-4 py-5 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-[var(--color-text-primary)]">Bills</h1>
          {!loading && (
            <p className="text-xs text-[var(--color-text-tertiary)] mt-0.5">
              {bills.length} {bills.length === 1 ? 'record' : 'records'}
            </p>
          )}
        </div>
        <Button
          variant="primary"
          size="sm"
          onClick={() => navigate('/scan')}
          leftIcon={<ScanLine size={14} />}
        >
          Scan
        </Button>
      </div>

      {/* Search + filter bar */}
      <div className="flex gap-2">
        <div className="flex-1">
          <Input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search merchant or category…"
            leftIcon={<Search size={15} />}
          />
        </div>
        <button
          onClick={() => setFilterOpen(true)}
          className={`
            flex items-center justify-center gap-1.5 px-3 py-2 rounded-[var(--radius-md)]
            border text-sm font-medium transition-all
            ${categoryFilter
              ? 'border-[var(--color-accent)] bg-[var(--color-accent-light)] text-[var(--color-accent-hover)]'
              : 'border-[var(--color-border)] text-[var(--color-text-secondary)] hover:border-[var(--color-border-strong)]'
            }
          `}
          aria-label="Filter"
        >
          <Filter size={15} />
          {categoryFilter ? <span className="text-xs">{categoryFilter.split(' ')[0]}</span> : null}
        </button>
        <button
          onClick={() => setSortOrder(o => o === 'date' ? 'amount' : 'date')}
          className="flex items-center justify-center px-3 py-2 rounded-[var(--radius-md)] border border-[var(--color-border)] text-[var(--color-text-secondary)] hover:border-[var(--color-border-strong)] transition-all"
          aria-label="Sort"
          title={`Sort by ${sortOrder === 'date' ? 'amount' : 'date'}`}
        >
          <SortDesc size={15} />
        </button>
      </div>

      {/* Active filter chip */}
      {categoryFilter && (
        <div className="flex items-center gap-2">
          <span className="text-xs text-[var(--color-text-secondary)]">Filtered by:</span>
          <button
            onClick={() => setCategoryFilter('')}
            className="text-xs font-medium px-2 py-1 rounded-sm bg-[var(--color-accent-light)] text-[var(--color-accent-hover)] border border-green-200 flex items-center gap-1 hover:bg-green-100 transition-colors"
          >
            {categoryFilter} ×
          </button>
        </div>
      )}

      {/* Bill list */}
      {loading ? (
        <div className="flex flex-col gap-2">
          {[0, 1, 2, 3].map(i => (
            <div key={i} className="h-16 rounded-[var(--radius-lg)] shimmer" />
          ))}
        </div>
      ) : bills.length === 0 ? (
        <EmptyState
          icon={<Receipt size={20} />}
          title={searchQuery || categoryFilter ? 'No matching bills' : 'No bills yet'}
          description={
            searchQuery || categoryFilter
              ? 'Try adjusting your search or filter.'
              : 'Scan your first bill to start tracking expenses.'
          }
          action={
            !searchQuery && !categoryFilter ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/scan')}
                leftIcon={<ScanLine size={14} />}
              >
                Scan First Bill
              </Button>
            ) : undefined
          }
        />
      ) : (
        <div className="flex flex-col gap-2">
          {bills.map(bill => (
            <BillCard
              key={bill.id}
              bill={bill}
              onClick={() => navigate(`/bills/${bill.id}`)}
            />
          ))}
        </div>
      )}

      {/* Filter modal */}
      <Modal open={filterOpen} onClose={() => setFilterOpen(false)} title="Filter by Category">
        <div className="flex flex-col gap-2">
          <button
            className={`w-full text-left px-3 py-2.5 rounded-[var(--radius-md)] text-sm transition-colors ${!categoryFilter ? 'bg-[var(--color-accent-light)] text-[var(--color-accent-hover)] font-medium' : 'hover:bg-[var(--color-surface-alt)]'}`}
            onClick={() => { setCategoryFilter(''); setFilterOpen(false) }}
          >
            All categories
          </button>
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              className={`w-full text-left px-3 py-2.5 rounded-[var(--radius-md)] text-sm transition-colors ${categoryFilter === cat ? 'bg-[var(--color-accent-light)] text-[var(--color-accent-hover)] font-medium' : 'hover:bg-[var(--color-surface-alt)]'}`}
              onClick={() => { setCategoryFilter(cat as Category); setFilterOpen(false) }}
            >
              {cat}
            </button>
          ))}
        </div>
      </Modal>
    </div>
  )
}
