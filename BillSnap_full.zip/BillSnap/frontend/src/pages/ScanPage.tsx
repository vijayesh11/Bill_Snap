import React, { useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlertTriangle, RefreshCw } from 'lucide-react'
import { ImageCapture } from '@/components/camera/ImageCapture'
import { ProcessingStatus } from '@/components/camera/ProcessingStatus'
import { ReviewForm } from '@/components/bills/ReviewForm'
import { Button } from '@/components/ui/Button'
import { useBills } from '@/hooks/useBills'
import { useToast } from '@/components/ui/Toast'
import { processBillImage } from '@/services/processingPipeline'
import type { ExtractedBillData, ProcessingState, Category } from '@/types'
import { todayISO } from '@/utils/formatting'

type Step = 'capture' | 'processing' | 'rejected' | 'review' | 'saved'

export function ScanPage() {
  const navigate = useNavigate()
  const { addBill } = useBills()
  const { showToast } = useToast()

  const [step, setStep] = useState<Step>('capture')
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null)
  const [processingState, setProcessingState] = useState<ProcessingState>({
    stage: 'idle', progress: 0, message: ''
  })
  const [extracted, setExtracted] = useState<ExtractedBillData | null>(null)
  const [saving, setSaving] = useState(false)

  const handleImageSelected = useCallback(async (dataUrl: string) => {
    setImageDataUrl(dataUrl)
    setStep('processing')
    setProcessingState({ stage: 'preprocessing', progress: 5, message: 'Starting…' })

    const result = await processBillImage(dataUrl, (state) => {
      setProcessingState(state)
    })

    if (!result) {
      setStep('capture')
      showToast('Processing failed. Please try again.', 'error')
      return
    }

    if (!result.isValid) {
      setExtracted(result)
      setStep('rejected')
      return
    }

    setExtracted(result)
    setStep('review')
  }, [showToast])

  const handleSave = useCallback(async (data: {
    merchant: string
    date: string
    amount: number
    currency: string
    category: Category
  }) => {
    if (!extracted) return
    setSaving(true)
    try {
      await addBill({
        ...data,
        imageDataUrl: imageDataUrl,
        confidence: extracted.confidence,
        rawText: extracted.rawText,
        createdAt: Date.now(),
        updatedAt: Date.now()
      })
      showToast('Bill saved successfully', 'success')
      navigate('/bills')
    } catch {
      showToast('Failed to save bill. Please try again.', 'error')
    } finally {
      setSaving(false)
    }
  }, [extracted, imageDataUrl, addBill, navigate, showToast])

  const handleReset = useCallback(() => {
    setStep('capture')
    setImageDataUrl(null)
    setExtracted(null)
    setProcessingState({ stage: 'idle', progress: 0, message: '' })
  }, [])

  return (
    <div className="max-w-lg mx-auto px-4 py-5">
      {/* Page header */}
      <div className="mb-5">
        <h1 className="text-xl font-bold text-[var(--color-text-primary)]">Scan Bill</h1>
        <p className="text-sm text-[var(--color-text-secondary)] mt-0.5">
          {step === 'capture' && 'Take a photo or upload from your gallery'}
          {step === 'processing' && 'Analysing your bill…'}
          {step === 'rejected' && 'Image not recognised as a bill'}
          {step === 'review' && 'Review and confirm extracted details'}
        </p>
      </div>

      {/* ── Capture ─────────────────────────────────────────────────────────── */}
      {step === 'capture' && (
        <ImageCapture
          onImageSelected={handleImageSelected}
          onCancel={() => navigate(-1)}
        />
      )}

      {/* ── Processing ──────────────────────────────────────────────────────── */}
      {step === 'processing' && (
        <div className="flex flex-col gap-6">
          {imageDataUrl && (
            <img
              src={imageDataUrl}
              alt="Processing"
              className="w-full max-h-56 object-contain rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface-alt)] opacity-70"
            />
          )}
          <ProcessingStatus state={processingState} />
        </div>
      )}

      {/* ── Rejected ────────────────────────────────────────────────────────── */}
      {step === 'rejected' && extracted && (
        <div className="flex flex-col items-center gap-4 py-4">
          {imageDataUrl && (
            <img
              src={imageDataUrl}
              alt="Uploaded"
              className="w-full max-h-48 object-contain rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface-alt)] opacity-80"
            />
          )}
          <div className="flex items-start gap-3 p-4 rounded-[var(--radius-lg)] bg-[var(--color-warning-light)] border border-amber-200 w-full">
            <AlertTriangle size={20} className="text-[var(--color-warning)] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-[var(--color-warning)]">
                This doesn't appear to be a bill or receipt
              </p>
              <p className="text-xs text-amber-700 mt-1 leading-relaxed">
                {extracted.classificationReason || 'Please upload a clear image of a valid bill or receipt.'}
              </p>
            </div>
          </div>

          <div className="text-xs text-[var(--color-text-tertiary)] text-center px-4">
            Tip: Ensure the bill is flat, well-lit, and the camera is directly above it.
          </div>

          <div className="flex flex-col gap-2 w-full">
            <Button
              variant="primary"
              onClick={handleReset}
              fullWidth
              leftIcon={<RefreshCw size={15} />}
            >
              Try Another Image
            </Button>
            <Button variant="ghost" onClick={() => navigate('/')} fullWidth>
              Go Home
            </Button>
          </div>
        </div>
      )}

      {/* ── Review ──────────────────────────────────────────────────────────── */}
      {step === 'review' && extracted && (
        <ReviewForm
          extracted={extracted}
          imageDataUrl={imageDataUrl}
          onSave={handleSave}
          onDiscard={handleReset}
          saving={saving}
        />
      )}
    </div>
  )
}
