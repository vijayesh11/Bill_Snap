import React, { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useLiveQuery } from 'dexie-react-hooks'
import { ChevronLeft, Edit2, Trash2, Check, X } from 'lucide-react'
import { db } from '@/database/db'
import { billRepository } from '@/database/billRepository'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Button } from '@/components/ui/Button'
import { Card, CardDivider } from '@/components/ui/Card'
import { Modal } from '@/components/ui/Modal'
import { useToast } from '@/components/ui/Toast'
import { formatCurrency, formatDate } from '@/utils/formatting'
import { CATEGORIES, type Category } from '@/types'

export function BillDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { showToast } = useToast()

  const bill = useLiveQuery(() => db.bills.get(Number(id)), [id])

  const [editing, setEditing] = useState(false)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)

  // Edit state
  const [merchant, setMerchant] = useState('')
  const [date, setDate] = useState('')
  const [amount, setAmount] = useState('')
  const [category, setCategory] = useState<Category>('Other')

  const startEdit = () => {
    if (!bill) return
    setMerchant(bill.merchant)
    setDate(bill.date)
    setAmount(String(bill.amount))
    setCategory(bill.category)
    setEditing(true)
  }

  const cancelEdit = () => setEditing(false)

  const saveEdit = async () => {
    if (!bill?.id) return
    const amt = parseFloat(amount)
    if (isNaN(amt) || amt < 0) { showToast('Please enter a valid amount', 'error'); return }
    if (!merchant.trim()) { showToast('Merchant name is required', 'error'); return }
    await billRepository.update(bill.id, { merchant: merchant.trim(), date, amount: amt, category })
    showToast('Bill updated', 'success')
    setEditing(false)
  }

  const handleDelete = async () => {
    if (!bill?.id) return
    setDeleting(true)
    await billRepository.delete(bill.id)
    showToast('Bill deleted', 'success')
    navigate('/bills')
  }

  if (!bill) {
    return (
      <div className="max-w-lg mx-auto px-4 py-8 text-center">
        <p className="text-sm text-[var(--color-text-secondary)]">Bill not found.</p>
        <Button variant="ghost" size="sm" onClick={() => navigate('/bills')} className="mt-4">
          Back to Bills
        </Button>
      </div>
    )
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-5 flex flex-col gap-5 fade-in">
      {/* Nav */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-1 text-sm text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] transition-colors"
        >
          <ChevronLeft size={18} />
          Back
        </button>
        <div className="flex gap-2">
          {!editing && (
            <>
              <Button variant="outline" size="sm" onClick={startEdit} leftIcon={<Edit2 size={14} />}>
                Edit
              </Button>
              <Button variant="danger" size="sm" onClick={() => setDeleteOpen(true)} leftIcon={<Trash2 size={14} />}>
                Delete
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Bill image */}
      {bill.imageDataUrl && (
        <img
          src={bill.imageDataUrl}
          alt="Bill"
          className="w-full max-h-56 object-contain rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface-alt)]"
        />
      )}

      {/* Detail card */}
      <Card padding="lg">
        {editing ? (
          <div className="flex flex-col gap-4">
            <Input label="Merchant" value={merchant} onChange={e => setMerchant(e.target.value)} />
            <Input label="Date" type="date" value={date} onChange={e => setDate(e.target.value)} />
            <Input label="Amount" type="number" min="0" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} />
            <Select
              label="Category"
              value={category}
              onChange={e => setCategory(e.target.value as Category)}
              options={CATEGORIES.map(c => ({ value: c, label: c }))}
            />
            <div className="flex gap-3 mt-2">
              <Button variant="ghost" size="sm" onClick={cancelEdit} leftIcon={<X size={14} />}>Cancel</Button>
              <Button variant="secondary" size="sm" onClick={saveEdit} fullWidth leftIcon={<Check size={14} />}>Save Changes</Button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-lg font-bold text-[var(--color-text-primary)]">{bill.merchant}</h2>
                <p className="text-sm text-[var(--color-text-tertiary)] mt-0.5">{formatDate(bill.date)}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-[var(--color-text-primary)]">
                  {formatCurrency(bill.amount, bill.currency)}
                </p>
                <span className="text-xs font-medium px-2 py-0.5 rounded-sm bg-[var(--color-surface-alt)] text-[var(--color-text-secondary)] border border-[var(--color-border)]">
                  {bill.category}
                </span>
              </div>
            </div>

            <CardDivider />

            <div className="grid grid-cols-2 gap-y-3 text-sm">
              <div>
                <p className="text-xs text-[var(--color-text-tertiary)] mb-0.5">Currency</p>
                <p className="font-medium">{bill.currency}</p>
              </div>
              <div>
                <p className="text-xs text-[var(--color-text-tertiary)] mb-0.5">Saved on</p>
                <p className="font-medium">{new Date(bill.createdAt).toLocaleDateString('en-IN')}</p>
              </div>
            </div>
          </>
        )}
      </Card>

      {/* Delete confirmation */}
      <Modal open={deleteOpen} onClose={() => setDeleteOpen(false)} title="Delete Bill" size="sm">
        <p className="text-sm text-[var(--color-text-secondary)] mb-5">
          Are you sure you want to delete the bill from <strong>{bill.merchant}</strong>? This cannot be undone.
        </p>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => setDeleteOpen(false)} fullWidth>Cancel</Button>
          <Button variant="danger" onClick={handleDelete} loading={deleting} fullWidth>Delete</Button>
        </div>
      </Modal>
    </div>
  )
}
