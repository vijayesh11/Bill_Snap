import React from 'react'
import { useNavigate } from 'react-router-dom'
import { ScanLine, TrendingUp, Receipt, ArrowRight, Wallet } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { EmptyState } from '@/components/ui/EmptyState'
import { BillCard } from '@/components/bills/BillCard'
import { useStats } from '@/hooks/useBills'
import { formatCurrency } from '@/utils/formatting'

export function HomePage() {
  const navigate = useNavigate()
  const { stats, loading } = useStats()

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const now = new Date()
  const currentMonth = monthNames[now.getMonth()]
  const hour = now.getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'

  return (
    <div
      className="fade-in"
      style={{ maxWidth: '32rem', margin: '0 auto', padding: '0 1rem 1.5rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}
    >
      {/* ── Page heading ─────────────────────────────────────────────── */}
      <div style={{ paddingTop: '1.25rem' }}>
        <p
          style={{
            fontSize: '11px',
            fontWeight: 500,
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: 'var(--color-text-tertiary)',
            margin: '0 0 4px',
          }}
        >
          {greeting}
        </p>
        <h1
          style={{
            fontSize: '26px',
            fontWeight: 800,
            letterSpacing: '-0.03em',
            color: 'var(--color-text-primary)',
            margin: 0,
          }}
        >
          Your Bills
        </h1>
      </div>

      {/* ── Hero scan card ───────────────────────────────────────────── */}
      <div
        style={{
          borderRadius: 'var(--radius-xl)',
          background: 'linear-gradient(135deg, var(--color-navy) 0%, #1f3f63 60%, #163552 100%)',
          padding: '1.5rem',
          boxShadow: 'var(--shadow-navy)',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* Decorative circle */}
        <div
          style={{
            position: 'absolute',
            top: '-40px',
            right: '-40px',
            width: '160px',
            height: '160px',
            borderRadius: '50%',
            background: 'rgba(255,255,255,0.04)',
            pointerEvents: 'none',
          }}
        />
        <div
          style={{
            position: 'absolute',
            bottom: '-20px',
            right: '30px',
            width: '80px',
            height: '80px',
            borderRadius: '50%',
            background: 'rgba(255,255,255,0.04)',
            pointerEvents: 'none',
          }}
        />

        {/* Content */}
        <div style={{ position: 'relative' }}>
          <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.55)', margin: '0 0 4px', fontWeight: 500 }}>
            Ready to track?
          </p>
          <h2
            style={{
              fontSize: '20px',
              fontWeight: 700,
              color: '#fff',
              letterSpacing: '-0.025em',
              margin: '0 0 16px',
            }}
          >
            Snap a bill
          </h2>

          <button
            onClick={() => navigate('/scan')}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '8px',
              background: 'rgba(255,255,255,0.14)',
              border: '1px solid rgba(255,255,255,0.22)',
              borderRadius: 'var(--radius-pill)',
              color: '#fff',
              fontSize: '14px',
              fontWeight: 600,
              padding: '10px 20px',
              cursor: 'pointer',
              transition: 'background 0.15s ease',
              letterSpacing: '-0.01em',
              backdropFilter: 'blur(8px)',
            }}
            onMouseEnter={e => ((e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.22)')}
            onMouseLeave={e => ((e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.14)')}
          >
            <ScanLine size={16} strokeWidth={2} />
            Scan Bill
          </button>
        </div>
      </div>

      {/* ── Stats row ─────────────────────────────────────────────────── */}
      {loading ? (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          {[0, 1].map(i => (
            <div key={i} className="shimmer" style={{ height: '90px' }} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          {/* This month */}
          <div
            style={{
              background: 'var(--color-surface)',
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-lg)',
              padding: '14px 16px',
              boxShadow: 'var(--shadow-xs)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
              <TrendingUp size={13} color="var(--color-text-tertiary)" strokeWidth={2} />
              <span style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {currentMonth} Spent
              </span>
            </div>
            <p
              className="amount"
              style={{ fontSize: '22px', fontWeight: 800, letterSpacing: '-0.03em', color: 'var(--color-text-primary)', margin: '0 0 2px' }}
            >
              {formatCurrency(stats?.thisMonthSpending ?? 0)}
            </p>
            <p style={{ fontSize: '11px', color: 'var(--color-text-tertiary)', margin: 0 }}>
              {stats?.thisMonthBills ?? 0} bills
            </p>
          </div>

          {/* All time */}
          <div
            style={{
              background: 'var(--color-surface)',
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-lg)',
              padding: '14px 16px',
              boxShadow: 'var(--shadow-xs)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
              <Wallet size={13} color="var(--color-text-tertiary)" strokeWidth={2} />
              <span style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                All Time
              </span>
            </div>
            <p
              className="amount"
              style={{ fontSize: '22px', fontWeight: 800, letterSpacing: '-0.03em', color: 'var(--color-text-primary)', margin: '0 0 2px' }}
            >
              {formatCurrency(stats?.totalSpending ?? 0)}
            </p>
            <p style={{ fontSize: '11px', color: 'var(--color-text-tertiary)', margin: 0 }}>
              {stats?.totalBills ?? 0} bills total
            </p>
          </div>
        </div>
      )}

      {/* ── Recent bills ─────────────────────────────────────────────── */}
      <div>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '12px',
          }}
        >
          <h2
            style={{
              fontSize: '14px',
              fontWeight: 700,
              color: 'var(--color-text-primary)',
              letterSpacing: '-0.01em',
              margin: 0,
            }}
          >
            Recent Bills
          </h2>
          {(stats?.totalBills ?? 0) > 0 && (
            <button
              onClick={() => navigate('/bills')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                fontSize: '13px',
                fontWeight: 600,
                color: 'var(--color-accent)',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: 0,
              }}
            >
              View all <ArrowRight size={13} />
            </button>
          )}
        </div>

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {[0, 1, 2].map(i => (
              <div key={i} className="shimmer" style={{ height: '70px' }} />
            ))}
          </div>
        ) : (stats?.recentBills.length ?? 0) === 0 ? (
          <EmptyState
            icon={<Receipt size={20} />}
            title="No bills yet"
            description="Snap your first bill to start tracking expenses."
            action={
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/scan')}
                leftIcon={<ScanLine size={15} />}
              >
                Scan First Bill
              </Button>
            }
          />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {stats!.recentBills.map(bill => (
              <BillCard
                key={bill.id}
                bill={bill}
                onClick={() => navigate(`/bills/${bill.id}`)}
                compact
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
