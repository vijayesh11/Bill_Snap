export type Category =
  | 'Food'
  | 'Groceries'
  | 'Shopping'
  | 'Transport'
  | 'Healthcare'
  | 'Education'
  | 'Utilities'
  | 'Entertainment'
  | 'Travel'
  | 'Fuel'
  | 'Restaurant'
  | 'Other'

export const CATEGORIES: Category[] = [
  'Food',
  'Groceries',
  'Shopping',
  'Transport',
  'Healthcare',
  'Education',
  'Utilities',
  'Entertainment',
  'Travel',
  'Fuel',
  'Restaurant',
  'Other'
]

export type ConfidenceLevel = 'high' | 'medium' | 'low'

export interface FieldConfidence {
  merchant: ConfidenceLevel
  date: ConfidenceLevel
  amount: ConfidenceLevel
  category: ConfidenceLevel
}

export interface ExtractedBillData {
  merchant: string
  date: string        // ISO date string YYYY-MM-DD
  amount: number
  currency: string
  category: Category
  confidence: FieldConfidence
  rawText: string
  isValid: boolean
  classificationConfidence: number  // 0–1
  classificationReason: string
  /** Set by the backend when Vision AI was used; absent when OCR fallback ran. */
  extractionMethod?: 'vision-api' | 'ocr'
}

export interface Bill {
  id?: number
  merchant: string
  date: string
  amount: number
  currency: string
  category: Category
  imageDataUrl: string | null
  confidence: FieldConfidence
  rawText: string
  createdAt: number  // timestamp
  updatedAt: number
}

export interface ProcessingState {
  stage: 'idle' | 'preprocessing' | 'ocr' | 'classifying' | 'extracting' | 'done' | 'error'
  progress: number
  message: string
  error?: string
}

export interface ClassificationResult {
  isBill: boolean
  confidence: number
  reason: string
}

export interface DashboardStats {
  totalBills: number
  totalSpending: number
  thisMonthSpending: number
  thisMonthBills: number
  spendingByCategory: Record<string, number>
  recentBills: Bill[]
}
