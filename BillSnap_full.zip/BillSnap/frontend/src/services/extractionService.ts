/**
 * Structured field extraction from OCR text.
 *
 * Fields extracted:
 * - Merchant name
 * - Date
 * - Total amount
 * - Category suggestion
 *
 * Each field returns a value and a ConfidenceLevel based on evidence quality.
 */

import type { Category, ConfidenceLevel, ExtractedBillData, FieldConfidence } from '@/types'

// ── Date extraction ──────────────────────────────────────────────────────────

const MONTH_MAP: Record<string, number> = {
  jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6,
  jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12,
  january: 1, february: 2, march: 3, april: 4, june: 6,
  july: 7, august: 8, september: 9, october: 10, november: 11, december: 12
}

function normaliseYear(y: string): number {
  const n = parseInt(y)
  if (n < 100) return n < 50 ? 2000 + n : 1900 + n
  return n
}

function extractDate(text: string): { value: string; confidence: ConfidenceLevel } {
  // ISO / numeric formats: 2024-11-04 | 04/11/2024 | 04-11-24
  const numericRe = /\b(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})\b/g
  // Named month: 04 Nov 2024 / November 4, 2024 / 23 - Jan - 2025
  const namedRe = /\b(\d{1,2})[\s\-]+(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)[\s\-]+(\d{2,4})\b/gi
  const namedRe2 = /\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+(\d{1,2}),?\s+(\d{2,4})\b/gi

  // Try named month first (higher confidence)
  let m = namedRe.exec(text)
  if (m) {
    const day = parseInt(m[1])
    const mon = MONTH_MAP[m[2].slice(0, 3).toLowerCase()]
    const year = normaliseYear(m[3])
    if (day >= 1 && day <= 31 && mon) {
      const iso = `${year}-${String(mon).padStart(2, '0')}-${String(day).padStart(2, '0')}`
      return { value: iso, confidence: 'high' }
    }
  }

  m = namedRe2.exec(text)
  if (m) {
    const mon = MONTH_MAP[m[1].slice(0, 3).toLowerCase()]
    const day = parseInt(m[2])
    const year = normaliseYear(m[3])
    if (day >= 1 && day <= 31 && mon) {
      const iso = `${year}-${String(mon).padStart(2, '0')}-${String(day).padStart(2, '0')}`
      return { value: iso, confidence: 'high' }
    }
  }

  // Try numeric formats
  numericRe.lastIndex = 0
  const candidates: Array<{ iso: string; score: number }> = []
  let nm: RegExpExecArray | null
  while ((nm = numericRe.exec(text)) !== null) {
    let d = parseInt(nm[1]), mon = parseInt(nm[2]), y = normaliseYear(nm[3])
    // If month > 12, try swapping
    if (mon > 12 && d <= 12) { [d, mon] = [mon, d] }
    if (d < 1 || d > 31 || mon < 1 || mon > 12) continue
    const iso = `${y}-${String(mon).padStart(2, '0')}-${String(d).padStart(2, '0')}`
    candidates.push({ iso, score: y > 2000 ? 2 : 1 })
  }

  if (candidates.length > 0) {
    const best = candidates.sort((a, b) => b.score - a.score)[0]
    return { value: best.iso, confidence: candidates.length === 1 ? 'medium' : 'low' }
  }

  // Fallback: today
  return { value: new Date().toISOString().slice(0, 10), confidence: 'low' }
}

// ── Amount extraction ────────────────────────────────────────────────────────

function extractAmount(text: string): { value: number; currency: string; confidence: ConfidenceLevel } {
  const lines = text.split('\n')

  // Priority labels for total line detection (descending priority)
  const totalLabels = [
    'grand total', 'net payable', 'amount due', 'amount paid', 'total amount',
    'net amount', 'total', 'sub total', 'subtotal', 'payable'
  ]

  const currencySymRe = /(?:₹|rs\.?|inr|\$|£|€)/i
  // Amount pattern: optional currency, digits with optional commas, optional decimal
  const amountRe = /(?:₹|rs\.?|inr|\$|£|€)?\s*([\d,]+(?:\.\d{1,2})?)/gi

  let currency = '₹'

  // 1. Search for labelled total lines
  for (const label of totalLabels) {
    for (const line of lines) {
      const ll = line.toLowerCase()
      if (!ll.includes(label)) continue

      // Extract the rightmost number on the line
      const matches = [...line.matchAll(/[\d,]+(?:\.\d{1,2})?/g)]
      if (matches.length === 0) continue
      const raw = matches[matches.length - 1][0].replace(/,/g, '')
      const val = parseFloat(raw)
      if (!isNaN(val) && val > 0) {
        if (currencySymRe.test(line)) {
          if (line.includes('₹') || /rs\.?/i.test(line)) currency = '₹'
          else if (line.includes('$')) currency = '$'
          else if (line.includes('£')) currency = '£'
        }
        return {
          value: val,
          currency,
          confidence: label === 'total' || label === 'grand total' ? 'high' : 'medium'
        }
      }
    }
  }

  // 2. Fall back: largest currency-preceded amount in full text
  amountRe.lastIndex = 0
  const allAmounts: number[] = []
  let am: RegExpExecArray | null
  while ((am = amountRe.exec(text)) !== null) {
    const val = parseFloat(am[1].replace(/,/g, ''))
    if (!isNaN(val) && val > 0 && val < 1_000_000) allAmounts.push(val)
  }

  if (allAmounts.length > 0) {
    // Largest amount is usually the grand total
    const val = Math.max(...allAmounts)
    return { value: val, currency, confidence: 'low' }
  }

  return { value: 0, currency: '₹', confidence: 'low' }
}

// ── Merchant extraction ──────────────────────────────────────────────────────

function extractMerchant(text: string): { value: string; confidence: ConfidenceLevel } {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean)

  // Skip lines that look like dates, amounts, or single characters
  const skipRe = /^(\d+[\/\-\.]\d+|₹|rs\.|total|invoice|receipt|tax|gst|thank|www\.|http)/i
  const shortSkip = (s: string) => s.length < 3 || /^\W+$/.test(s)

  // First 5 non-trivial lines are most likely to contain merchant name
  const candidates = lines.slice(0, 8).filter(l => !skipRe.test(l) && !shortSkip(l))

  if (candidates.length > 0) {
    // Prefer lines that look like a business name: mixed case, not all digits
    const best = candidates.find(l => /[A-Z]/.test(l) && !/^\d+$/.test(l)) ?? candidates[0]
    return {
      value: best.replace(/[^\w\s\-&.,()]/g, '').trim().slice(0, 60),
      confidence: candidates.length >= 2 ? 'medium' : 'low'
    }
  }

  return { value: 'Unknown Merchant', confidence: 'low' }
}

// ── Category classification ──────────────────────────────────────────────────

type CategoryRule = { keywords: string[]; category: Category }

const CATEGORY_RULES: CategoryRule[] = [
  {
    keywords: ['restaurant', 'cafe', 'coffee', 'pizza', 'burger', 'biryani', 'bar',
      'swiggy', 'zomato', 'dining', 'food court', 'bakery', 'tiffin', 'dhaba', 'kfc',
      'mcdonald', 'domino', 'subway', 'starbucks'],
    category: 'Restaurant'
  },
  {
    keywords: ['hotel', 'lodge', 'inn', 'accommodation', 'resort', 'guest house', 'hostel'],
    category: 'Travel'
  },
  {
    keywords: ['food', 'snack', 'breakfast', 'lunch', 'dinner', 'meal', 'eat', 'canteen'],
    category: 'Food'
  },
  {
    keywords: ['grocery', 'supermarket', 'mart', 'fresh', 'vegetables', 'fruits', 'milk',
      'dairy', 'big bazaar', 'dmart', 'reliance smart', 'more', 'nature basket',
      'spencers', 'easyday', 'kirana', 'provision', 'general store', 'cold storage',
      'walnut', 'almond', 'cashew', 'dry fruit', 'nuts', 'cheese', 'paneer', 'curd',
      'yogurt', 'ghee', 'atta', 'maida', 'rice', 'dal', 'lentil', 'flour',
      'rose water', 'coconut oil', 'mustard oil', 'olive oil', 'spice', 'masala',
      'biscuit', 'snack', 'breakfast', 'cereal', 'oats', 'sugar', 'salt'],
    category: 'Groceries'
  },
  {
    keywords: ['electricity', 'electric', 'power', 'water', 'gas', 'lpg', 'internet',
      'broadband', 'wifi', 'mobile bill', 'telephone', 'recharge', 'utility',
      'bescom', 'msedcl', 'bsnl', 'airtel', 'jio', 'vi', 'tata sky', 'dth'],
    category: 'Utilities'
  },
  {
    keywords: ['petrol', 'diesel', 'pump', 'cng', 'hp', 'ioc', 'bharat petroleum', 'indian oil'],
    category: 'Fuel'
  },
  {
    keywords: ['ola', 'uber', 'rapido', 'taxi', 'auto', 'bus', 'train', 'metro',
      'flight', 'airline', 'parking', 'toll', 'transport'],
    category: 'Transport'
  },
  {
    keywords: ['hospital', 'clinic', 'pharmacy', 'medical', 'doctor', 'medicine',
      'health', 'diagnostic', 'lab', 'pathology', 'apollo', 'fortis', 'manipal',
      'max hospital', 'medplus', 'netmeds'],
    category: 'Healthcare'
  },
  {
    keywords: ['amazon', 'flipkart', 'myntra', 'shopping', 'clothes', 'fashion',
      'garments', 'shoes', 'footwear', 'electronics', 'mobile', 'laptop',
      'appliance', 'gift', 'toy', 'book shop', 'stationery'],
    category: 'Shopping'
  },
  {
    keywords: ['movie', 'cinema', 'pvr', 'inox', 'netflix', 'amazon prime', 'hotstar',
      'concert', 'event', 'game', 'gaming', 'sports', 'gym', 'fitness', 'spa', 'salon'],
    category: 'Entertainment'
  },
  {
    keywords: ['school', 'college', 'university', 'course', 'tuition', 'coaching',
      'udemy', 'coursera', 'byju', 'unacademy', 'exam', 'fee', 'admission', 'library'],
    category: 'Education'
  }
]

function suggestCategory(text: string, merchant: string): { value: Category; confidence: ConfidenceLevel } {
  const combined = (text + ' ' + merchant).toLowerCase()

  let bestCategory: Category = 'Other'
  let bestScore = 0

  for (const rule of CATEGORY_RULES) {
    let score = 0
    for (const kw of rule.keywords) {
      if (combined.includes(kw)) score++
    }
    if (score > bestScore) {
      bestScore = score
      bestCategory = rule.category
    }
  }

  const confidence: ConfidenceLevel = bestScore >= 2 ? 'high' : bestScore === 1 ? 'medium' : 'low'
  return { value: bestCategory, confidence }
}

// ── Overall confidence ───────────────────────────────────────────────────────

function computeOverallConfidence(
  ocrConfidence: number,
  fieldConf: FieldConfidence
): void {
  // No-op — confidence per field already computed above.
  // ocrConfidence is used by the calling pipeline to adjust field confidence.
  void ocrConfidence
  void fieldConf
}

// ── Main entry ───────────────────────────────────────────────────────────────

export function extractBillFields(
  ocrText: string,
  ocrConfidence: number,
  classificationConfidence: number,
  classificationReason: string
): ExtractedBillData {
  const dateResult = extractDate(ocrText)
  const amountResult = extractAmount(ocrText)
  const merchantResult = extractMerchant(ocrText)
  const categoryResult = suggestCategory(ocrText, merchantResult.value)

  // Downgrade field confidences when OCR itself is poor
  function maybeDowngrade(c: ConfidenceLevel): ConfidenceLevel {
    if (ocrConfidence < 40) {
      if (c === 'high') return 'medium'
      if (c === 'medium') return 'low'
    }
    return c
  }

  const confidence: FieldConfidence = {
    merchant: maybeDowngrade(merchantResult.confidence),
    date: maybeDowngrade(dateResult.confidence),
    amount: maybeDowngrade(amountResult.confidence),
    category: maybeDowngrade(categoryResult.confidence)
  }

  computeOverallConfidence(ocrConfidence, confidence)

  return {
    merchant: merchantResult.value,
    date: dateResult.value,
    amount: amountResult.value,
    currency: amountResult.currency,
    category: categoryResult.value,
    confidence,
    rawText: ocrText,
    isValid: true,
    classificationConfidence,
    classificationReason
  }
}
