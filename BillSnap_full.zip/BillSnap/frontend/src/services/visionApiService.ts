/**
 * Groq AI Service — VLM-style reasoning for printed + handwritten bills.
 * Handles Indian GST bills, cash memos, handwritten receipts.
 */

import type { ExtractedBillData, Category } from '@/types'

const GROQ_API_KEY = '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'
const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'

const TEXT_MODELS = [
  'openai/gpt-oss-120b',
  'openai/gpt-oss-20b',
  'qwen/qwen3.8-27b',
  'allam-2-7b',
]

const CATEGORIES = [
  'Food', 'Groceries', 'Shopping', 'Transport', 'Healthcare',
  'Education', 'Utilities', 'Entertainment', 'Travel', 'Fuel', 'Restaurant', 'Other',
]

function detectCurrency(text: string): string {
  const t = text.toLowerCase()
  if (t.includes('rs') || t.includes('inr') || t.includes('rupee')) return 'INR'
  if (t.includes('gbp') || t.includes('pound')) return 'GBP'
  if (t.includes('eur') || t.includes('euro')) return 'EUR'
  if (t.includes('usd') || t.includes('dollar')) return 'USD'
  return 'INR'
}

async function callGroq(model: string, ocrText: string): Promise<any> {
  const currency = detectCurrency(ocrText)

  const prompt = `You are an expert AI agent combining OCR correction and Vision-Language Model (VLM) reasoning to extract data from handwritten and printed Indian bills.

The input is OCR text from a real bill image. OCR on handwritten/printed text produces errors. REASON through the garbled output and reconstruct correct values like a human reading the original paper.

OCR TEXT:
"""
${ocrText}
"""

DETECTED CURRENCY: ${currency}

═══════════════════════════════════════
PART A — IGNORE THESE (they are NOT amounts)
═══════════════════════════════════════
GSTIN numbers:   format like "07AAGPN2913H2U" — 15-character alphanumeric = TAX ID, never amount
PAN numbers:     format like "AAGPN2913H" — 10-character = PAN card, never amount
Invoice numbers: "Invoice No. 345", "Bill No. 19" — small numbers at top right = serial, never amount
Phone numbers:   7-10 digit numbers with no Rs prefix = phone, never amount
HSN codes:       4-8 digit codes in HSN/SAC column = product classification, never amount
State codes:     "State Code: 07" = GST state code, never amount
Qty / Rate:      numbers in Qty and Rate columns are NOT the final amount

═══════════════════════════════════════
PART B — HANDWRITING OCR CORRECTIONS
═══════════════════════════════════════
PAISE COLUMN — handwritten "00" after amount is always misread as:
  "w" "ww" "u" "uu" "v" "vv" "co" "oo" "OO" "c" "-" "/"
  FIX: "2755 w" → 2755.00  |  "43 co" → 43.00  |  "60 oo" → 60.00

INDIAN "/-" NOTATION:
  "Rs 2700/-" or "2700/-" → amount is 2700.00  (the /- means "rupees only")

DIGIT MISREADS:
  "l" or "I" at start of number line → "1"
  "O" between digits → "0"

═══════════════════════════════════════
PART C — GST BILL STRUCTURE (very common in India)
═══════════════════════════════════════
Indian GST bills have this structure at the bottom:
  Total (pre-tax)   :  2700.00   ← subtotal before tax
  SGST @ 9%         :   243.00   ← state tax
  CGST @ 9%         :   243.00   ← central tax
  Total Invoice Value:  3186.00  ← FINAL amount customer pays

RULE: If you see SGST/CGST/IGST lines → pick "Total Invoice Value" as the final amount.
If no GST lines → pick the "Total" or "Grand Total" line.

═══════════════════════════════════════
PART D — EXTRACT THE 4 FIELDS
═══════════════════════════════════════

MERCHANT:
  → Business name from bill header (top of bill)
  → Ignore taglines, addresses, emails, phone numbers
  → Example: "NATH TRADERS" is the merchant, "2880 BAZAR SRIKIWALAN" is the address

DATE:
  → Return YYYY-MM-DD
  → "1.10.2024" → 2024-10-01  |  "13-11-87" → 1987-11-13
  → 2-digit years: 00-29 = 2000s, 30-99 = 1900s
  → Return null if not found — NEVER use today's date

AMOUNT (priority order):
  #1  SGST/CGST present → "Total Invoice Value" = final amount
  #2  "Rs XXX/-" or "XXX/-" anywhere = final total
  #3  Label: "Total" / "Grand Total" / "Net Amount" / "Amount Payable"
  #4  Subtotal - Discount = final (use smallest/last number)
  #5  Amount in words: "Three Thousand One Hundred Eighty Six" → 3186.00
  
  NEVER use: GSTIN, PAN, invoice numbers, phone numbers, HSN codes, state codes

CURRENCY: Rs/INR → INR | $ → USD | £ → GBP | default: ${currency}

CATEGORY — pick one: ${CATEGORIES.join(', ')}
  Trader/wholesaler/hardware/industrial supplies → Shopping
  Restaurant/cafe/dhaba/hotel dining → Restaurant
  Hotel stay/lodge/resort → Travel
  Petrol/diesel pump → Fuel
  Taxi/auto/bus/train/flight → Transport
  Hospital/pharmacy/clinic/lab → Healthcare
  School/college/books/stationery → Education
  Electricity/water/gas/phone → Utilities
  Supermarket/kirana/grocery → Groceries
  Cinema/event/game/gym → Entertainment

BILL CLASSIFICATION:
  YES — bill: any receipt with item list + prices + total (any language)
  "CASH MEMO" = definitely a bill
  GST invoice = definitely a bill
  NO — not bill: ID cards, photos, news articles, menus without totals

═══════════════════════════════════════
PART E — CONFIDENCE
═══════════════════════════════════════
"high"   = found with explicit label, clearly readable   → VERIFIED
"medium" = inferred with good confidence                 → REVIEW  
"low"    = unclear, could not confirm                    → UNCERTAIN

Return null for value + "low" confidence if field cannot be determined.
NEVER invent values not visible in the OCR text.

Respond ONLY with valid JSON — no markdown, no extra text:
{
  "isBill": true,
  "notBillReason": "only if isBill is false",
  "merchant": { "value": "Nath Traders", "confidence": "high" },
  "date":     { "value": "2024-10-01",   "confidence": "high" },
  "amount":   { "value": 3186.00, "currency": "INR", "confidence": "high" },
  "category": { "value": "Shopping",     "confidence": "high" }
}`

  const res = await fetch(GROQ_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model,
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 512,
      temperature: 0.1,
    }),
  })

  const body = await res.text()
  if (!res.ok) {
    const err = new Error(`Groq ${res.status}: ${body}`)
    ;(err as any).status = res.status
    throw err
  }

  const json = JSON.parse(body)
  const content: string = json.choices?.[0]?.message?.content ?? ''
  if (!content) throw new Error('Empty response from Groq')

  return JSON.parse(
    content.replace(/^```json\s*/i, '').replace(/\s*```$/i, '').trim()
  )
}

async function callGroqWithFallback(ocrText: string): Promise<any> {
  let lastError: Error | null = null
  for (const model of TEXT_MODELS) {
    try {
      console.log(`[BillSnap] Trying: ${model}`)
      const result = await callGroq(model, ocrText)
      console.log(`[BillSnap] Success: ${model}`)
      return result
    } catch (err: any) {
      console.warn(`[BillSnap] ${model} failed:`, err.message)
      lastError = err
      if (err.status === 401) throw new Error('Invalid Groq API key')
      if (err.status === 429) throw new Error('Groq rate limit — please wait and retry')
    }
  }
  throw new Error(`All Groq models unavailable. Last: ${lastError?.message}`)
}

export interface GroqAnalysisResult {
  success: boolean
  isBill: boolean
  notBillReason?: string
  data?: ExtractedBillData
  error?: string
}

export async function analyzeWithGroq(ocrText: string): Promise<GroqAnalysisResult> {
  if (!GROQ_API_KEY) {
    return { success: false, isBill: false, error: 'Groq API key not set.' }
  }
  try {
    const raw = await callGroqWithFallback(ocrText)

    if (!raw.isBill) {
      return {
        success: true,
        isBill: false,
        notBillReason: raw.notBillReason ?? 'This does not appear to be a bill or receipt.',
      }
    }

    const rawAmount = raw.amount?.value
    const amount = rawAmount && rawAmount > 0 ? parseFloat(String(rawAmount)) : 0
    const currency = raw.amount?.currency ?? detectCurrency(ocrText)

    const data: ExtractedBillData = {
      merchant:  raw.merchant?.value ?? 'Unknown Merchant',
      date:      raw.date?.value     ?? '',
      amount,
      currency,
      category:  (CATEGORIES.includes(raw.category?.value) ? raw.category.value : 'Other') as Category,
      confidence: {
        merchant: raw.merchant?.confidence ?? 'low',
        date:     raw.date?.confidence     ?? 'low',
        amount:   raw.amount?.confidence   ?? 'low',
        category: raw.category?.confidence ?? 'low',
      },
      rawText:                  ocrText,
      isValid:                  true,
      classificationConfidence: 0.95,
      classificationReason:     'Classified by Groq AI',
      extractionMethod:         'vision-api',
    }

    return { success: true, isBill: true, data }
  } catch (err: any) {
    return { success: false, isBill: false, error: err.message ?? 'Groq analysis failed' }
  }
}

export function isBackendConfigured(): boolean {
  return Boolean(GROQ_API_KEY)
}
