/**
 * Processing Pipeline — full ML pipeline for bill analysis.
 *
 * Stage 1: Image preprocessing (grayscale + contrast boost for blurry images)
 * Stage 2: OCR text extraction (Tesseract.js — runs on device, no upload)
 * Stage 3: Quick heuristic pre-check (too little text? → reject early)
 * Stage 4: Groq AI — classify + extract merchant/date/total/category in one call
 * Stage 5: Fallback to regex extraction if Groq is unavailable
 */

import { preprocessImage } from '@/utils/imageProcessing'
import { runOcr } from './ocrService'
import { classifyBill } from './classificationService'
import { extractBillFields } from './extractionService'
import { analyzeWithGroq } from './visionApiService'
import type { ExtractedBillData, ProcessingState } from '@/types'

export type ProgressCallback = (state: ProcessingState) => void

export async function processBillImage(
  imageDataUrl: string,
  onProgress: ProgressCallback
): Promise<ExtractedBillData | null> {
  try {
    // ── Stage 1: Image preprocessing ─────────────────────────────────────────
    // Grayscale + contrast boost helps OCR on blurry, dim, or faded images
    onProgress({ stage: 'preprocessing', progress: 10, message: 'Preparing image…' })
    const { grayscaleDataUrl } = await preprocessImage(imageDataUrl)

    // ── Stage 2: OCR ─────────────────────────────────────────────────────────
    // Runs entirely on the device — the image is never uploaded at this stage
    onProgress({ stage: 'ocr', progress: 30, message: 'Reading text from image…' })
    const { text: ocrText, confidence: ocrConfidence } = await runOcr(grayscaleDataUrl)

    // ── Stage 3: Quick heuristic pre-check ───────────────────────────────────
    // Reject immediately if OCR found almost nothing (blank image, pure photo)
    onProgress({ stage: 'classifying', progress: 55, message: 'Verifying bill…' })
    const heuristic = classifyBill(ocrText, ocrConfidence)

    if (!heuristic.isBill && ocrText.trim().length < 15) {
      // OCR found almost no text — almost certainly not a bill image
      onProgress({ stage: 'done', progress: 100, message: 'Not a bill' })
      return {
        merchant: '',
        date: '',
        amount: 0,
        currency: 'INR',
        category: 'Other',
        confidence: { merchant: 'low', date: 'low', amount: 'low', category: 'low' },
        rawText: ocrText,
        isValid: false,
        classificationConfidence: 0.05,
        classificationReason: 'No readable text found in the image. Please take a clearer photo of your bill.',
      }
    }

    // ── Stage 4: Groq AI — classify + extract ────────────────────────────────
    onProgress({ stage: 'extracting', progress: 70, message: 'Extracting bill details with AI…' })

    const groqResult = await analyzeWithGroq(ocrText)

    if (groqResult.success) {
      if (!groqResult.isBill) {
        // Groq confirmed this is not a bill
        onProgress({ stage: 'done', progress: 100, message: 'Not a bill' })
        return {
          merchant: '',
          date: '',
          amount: 0,
          currency: 'INR',
          category: 'Other',
          confidence: { merchant: 'low', date: 'low', amount: 'low', category: 'low' },
          rawText: ocrText,
          isValid: false,
          classificationConfidence: 0.1,
          classificationReason:
            groqResult.notBillReason ??
            'This does not appear to be a bill. Please upload a clear photo of a bill or receipt.',
        }
      }

      // Groq succeeded — return its structured extraction
      onProgress({ stage: 'done', progress: 100, message: 'Processing complete' })
      return groqResult.data!
    }

    // ── Stage 5: OCR regex fallback ───────────────────────────────────────────
    // Groq unavailable (no key, all models down, etc.) — use local heuristics
    console.warn('[BillSnap] Groq unavailable, falling back to OCR extraction:', groqResult.error)

    if (!heuristic.isBill) {
      onProgress({ stage: 'done', progress: 100, message: 'Not a bill' })
      return {
        merchant: '',
        date: '',
        amount: 0,
        currency: 'INR',
        category: 'Other',
        confidence: { merchant: 'low', date: 'low', amount: 'low', category: 'low' },
        rawText: ocrText,
        isValid: false,
        classificationConfidence: heuristic.confidence,
        classificationReason: heuristic.reason,
      }
    }

    const fallback = extractBillFields(
      ocrText,
      ocrConfidence,
      heuristic.confidence,
      heuristic.reason + ' (OCR fallback — Groq unavailable)',
    )

    onProgress({ stage: 'done', progress: 100, message: 'Processing complete (OCR mode)' })
    return { ...fallback, extractionMethod: 'ocr' as const }

  } catch (err) {
    const message = err instanceof Error ? err.message : 'An unexpected error occurred'
    onProgress({ stage: 'error', progress: 0, message, error: message })
    return null
  }
}
