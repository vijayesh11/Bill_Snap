/**
 * OCR Service — Tesseract.js with multi-pass PSM strategy.
 *
 * Handwriting recognition strategy:
 *  - Run THREE page-segmentation modes in parallel: PSM 6, PSM 4, PSM 11
 *  - PSM  6 = uniform block of text        (best for neat printed receipts)
 *  - PSM  4 = single column of text        (best for narrow bills)
 *  - PSM 11 = sparse text                  (best for scattered handwriting)
 *  - Pick the result with the highest Tesseract confidence score
 *  - Apply aggressive post-OCR cleanup before returning
 */
import { createWorker } from 'tesseract.js'

export interface OcrResult {
  text: string
  confidence: number
  psmUsed: string
}

// One persistent worker per PSM mode
const workers: Map<string, any> = new Map()

async function getWorker(psm: string) {
  if (!workers.has(psm)) {
    const w = await createWorker('eng', 1, {
      workerPath: 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/worker.min.js',
      langPath:   'https://tessdata.projectnaptha.com/4.0.0',
      corePath:   'https://cdn.jsdelivr.net/npm/tesseract.js-core@5/tesseract-core-simd-lstm.wasm.js',
      logger: () => {}
    })
    await w.setParameters({
      tessedit_pageseg_mode:    psm as any,
      preserve_interword_spaces: '1',
      // Allow all printable ASCII — do NOT whitelist digits only,
      // because we need merchant names and date strings too
    })
    workers.set(psm, w)
  }
  return workers.get(psm)
}

/**
 * Aggressive post-OCR cleanup for handwritten Indian bills.
 *
 * Key misread patterns:
 *   - Paise column "00" → w / ww / u / v / co / oo / c / -
 *   - Rs XXX/-  → normalize to Rs. XXX.00
 *   - "l" / "I" at start of number line → "1"
 *   - Pipe character → space
 */
function cleanOcrText(raw: string): string {
  return raw
    // ── Paise / cents column ──────────────────────────────────────────────
    // "60 w"  "60 ww"  "60 u"  "60 uu"  "60 v"  "60 vv"
    .replace(/(\d+)\s*[wWuUvV]{1,2}(?=\s|$)/gm, '$1.00')
    // "60 co"  "60 cu"  "60 au"  "60 ao"
    .replace(/(\d+)\s*[cCaA][oO0uU](?=\s|$)/gm, '$1.00')
    // "60 oo"  "60 OO"  "60 oO"
    .replace(/(\d+)\s*[oO]{2}(?=\s|$)/gm, '$1.00')
    // "60 c"  "60 o"  "60 -"  (single stray char after number)
    .replace(/(\d+)\s+[cCoO\-](?=\s|$)/gm, '$1.00')
    // "43 00" with space between integer and paise
    .replace(/(Rs\.?\:?\s*\d+)\s+00(?=\s|$)/gim, '$1.00')

    // ── Indian Rs XXX/- notation ──────────────────────────────────────────
    // "Rs 525/-"  "Rs. 525/-"  "Ro 525/"  (Ro = OCR misread of Rs)
    .replace(/[RrRo][sS]\.?\s*(\d[\d,]*)\s*\/[-]?/g, 'Rs. $1.00')
    // "Rs: 43 00" → "Rs: 43.00"
    .replace(/(Rs\.?\s*:?\s*\d+)\s+00(?=\s|$)/gi, '$1.00')

    // ── Common single-character misreads ──────────────────────────────────
    // "l4" or "I4" at line start → "14"
    .replace(/^([lI])(\d)/gm, '1$2')
    // Lone "l" between spaces → "1"
    .replace(/\bl\b/g, '1')
    // Letter "O" surrounded by digits → "0"
    .replace(/(\d)[Oo](\d)/g, '$10$2')

    // ── Table / layout noise ──────────────────────────────────────────────
    .replace(/\|/g, ' ')
    .replace(/_+/g, ' ')
    // Collapse runs of 3+ spaces to 2
    .replace(/ {3,}/g, '  ')
    // Remove totally blank lines (3+ in a row)
    .replace(/(\n\s*){3,}/g, '\n\n')
    .trim()
}

/**
 * Run OCR on a preprocessed (binarised) image using three PSM modes.
 * Returns the result with the best confidence score.
 */
export async function runOcr(imageDataUrl: string): Promise<OcrResult> {
  const PSM_MODES = [
    { psm: '6',  label: 'PSM6-block'   },   // uniform block — printed receipts
    { psm: '4',  label: 'PSM4-column'  },   // single column — narrow bills
    { psm: '11', label: 'PSM11-sparse' },   // sparse text   — handwriting
  ]

  // Run all three in parallel for speed
  const results = await Promise.allSettled(
    PSM_MODES.map(async ({ psm, label }) => {
      const worker = await getWorker(psm)
      const { data } = await worker.recognize(imageDataUrl)
      return {
        text:       cleanOcrText(data.text),
        confidence: data.confidence,
        psmUsed:    label,
      }
    })
  )

  // Pick the result with highest confidence that also has reasonable text length
  let best: OcrResult = { text: '', confidence: 0, psmUsed: 'none' }

  for (const r of results) {
    if (r.status === 'fulfilled') {
      const { text, confidence, psmUsed } = r.value
      // Weight: confidence score + bonus for longer extracted text
      const score = confidence + Math.min(20, text.length / 10)
      const bestScore = best.confidence + Math.min(20, best.text.length / 10)
      if (score > bestScore) {
        best = { text, confidence, psmUsed }
      }
    }
  }

  console.log(`[BillSnap OCR] Best result: ${best.psmUsed} (confidence ${best.confidence.toFixed(1)}%)`)
  console.log('[BillSnap OCR] Extracted text:\n', best.text)

  return best
}

export async function terminateOcr(): Promise<void> {
  for (const [, w] of workers) {
    await w.terminate()
  }
  workers.clear()
}
