/**
 * Bill/Non-Bill Classification Service
 *
 * Pipeline:
 * 1. OCR text analysis — look for receipt-specific keywords and patterns
 * 2. Structural heuristics — currency symbols, totals, item lists, merchant patterns
 * 3. Confidence scoring — weighted sum of signals
 * 4. Decision — bill / non-bill with confidence and human-readable reason
 *
 * This runs entirely in the browser with no external API, ensuring privacy
 * and offline capability. If a Vision LLM API key is configured, the
 * backend proxy endpoint enriches the result.
 */

import type { ClassificationResult } from '@/types'

// ── Keyword signals ──────────────────────────────────────────────────────────

const STRONG_BILL_KEYWORDS = [
  'total', 'subtotal', 'sub-total', 'grand total', 'amount due', 'amount paid',
  'invoice', 'receipt', 'bill', 'tax', 'gst', 'vat', 'cgst', 'sgst', 'igst',
  'payment', 'cash', 'paid', 'change', 'balance', 'thank you for shopping',
  'thank you for your visit', 'customer copy', 'order no', 'invoice no',
  'bill no', 'receipt no', 'txn', 'transaction'
]

const MEDIUM_BILL_KEYWORDS = [
  'qty', 'quantity', 'item', 'description', 'price', 'rate', 'unit',
  'discount', 'offer', 'mrp', 'net payable', 'inclusive of tax',
  'electricity', 'water', 'meter', 'reading', 'units consumed',
  'fuel', 'petrol', 'diesel', 'liters', 'pump',
  'restaurant', 'cafe', 'hotel', 'dine', 'menu',
  'grocery', 'supermarket', 'mart', 'store', 'shop',
  'amount', 'rs', '₹', 'inr', 'usd', 'eur', '£', '$'
]

const NON_BILL_INDICATORS = [
  'aadhaar', 'aadhar', 'pan card', 'passport', 'voter', 'driving licence',
  'selfie', 'photo', 'portrait', 'face', 'smile',
  'instagram', 'facebook', 'twitter', 'whatsapp', 'screenshot',
  'google maps', 'wikipedia', 'amazon product', 'flipkart listing',
  'ration card', 'birth certificate', 'marriage certificate'
]

// ── Regex patterns ───────────────────────────────────────────────────────────

// Currency amount patterns (₹1,234.56 / Rs. 1234 / $12.50 / €30)
const CURRENCY_PATTERN = /(?:₹|rs\.?|inr|usd|\$|£|€)\s*[\d,]+(?:\.\d{1,2})?/gi

// Date patterns
const DATE_PATTERN = /\b(?:\d{1,2}[-/\.]\d{1,2}[-/\.]\d{2,4}|\d{4}[-/\.]\d{1,2}[-/\.]\d{1,2}|\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{2,4})\b/gi

// Item line pattern: text followed by amount
const ITEM_LINE_PATTERN = /^.{3,40}\s+[\d,]+(?:\.\d{2})?$/gim

// ── Scoring ──────────────────────────────────────────────────────────────────

function scoreText(text: string): { score: number; signals: string[] } {
  const lower = text.toLowerCase()
  const signals: string[] = []
  let score = 0

  // Strong keywords — high signal
  let strongHits = 0
  for (const kw of STRONG_BILL_KEYWORDS) {
    if (lower.includes(kw)) strongHits++
  }
  if (strongHits >= 3) { score += 0.40; signals.push(`${strongHits} receipt keywords found`) }
  else if (strongHits >= 1) { score += 0.20; signals.push(`${strongHits} receipt keyword(s) found`) }

  // Medium keywords
  let medHits = 0
  for (const kw of MEDIUM_BILL_KEYWORDS) {
    if (lower.includes(kw)) medHits++
  }
  if (medHits >= 4) { score += 0.20; signals.push('Multiple commerce terms present') }
  else if (medHits >= 2) { score += 0.10 }

  // Currency amounts
  const amounts = lower.match(CURRENCY_PATTERN) ?? []
  if (amounts.length >= 2) { score += 0.15; signals.push(`${amounts.length} currency amounts detected`) }
  else if (amounts.length === 1) { score += 0.08 }

  // Date presence
  const dates = text.match(DATE_PATTERN) ?? []
  if (dates.length >= 1) { score += 0.10; signals.push('Date found') }

  // Item lines (multiple lines with trailing number)
  const itemLines = text.match(ITEM_LINE_PATTERN) ?? []
  if (itemLines.length >= 3) { score += 0.15; signals.push('Item list detected') }

  // Non-bill deductions
  for (const kw of NON_BILL_INDICATORS) {
    if (lower.includes(kw)) {
      score -= 0.30
      signals.push(`Non-bill indicator: "${kw}"`)
      break
    }
  }

  // Very short text — unlikely to be a parseable bill
  if (text.trim().length < 30) {
    score -= 0.20
    signals.push('Very little text extracted')
  }

  return { score: Math.min(1, Math.max(0, score)), signals }
}

// ── Main classification ──────────────────────────────────────────────────────

export function classifyBill(ocrText: string, ocrConfidence: number): ClassificationResult {
  if (!ocrText || ocrText.trim().length < 10) {
    return {
      isBill: false,
      confidence: 0.15,
      reason: 'No readable text found in the image. Please ensure the image is clear and well-lit.'
    }
  }

  const { score, signals } = scoreText(ocrText)

  // Adjust for low OCR confidence (blurry/rotated images can still be real bills)
  const ocrFactor = ocrConfidence < 30 ? 0.85 : 1  // slight penalty for very low OCR confidence

  const finalScore = score * ocrFactor
  const isBill = finalScore >= 0.30

  let reason: string
  if (isBill) {
    reason = signals.length > 0
      ? `Detected as bill: ${signals.slice(0, 2).join('; ')}`
      : 'Document characteristics match a bill or receipt'
  } else {
    const negSignal = signals.find(s => s.startsWith('Non-bill'))
    reason = negSignal
      ? negSignal.replace('Non-bill indicator: ', 'Contains identity or personal document markers: ')
      : 'No significant receipt characteristics detected'
  }

  return { isBill, confidence: finalScore, reason }
}

/** Assess whether a borderline result needs further review */
export function isUncertain(result: ClassificationResult): boolean {
  return result.confidence > 0.20 && result.confidence < 0.50
}
